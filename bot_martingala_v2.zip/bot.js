// Código del bot actualizado con logging y ML
console.log('Bot listo');