// modules/servidor_modelo.cjs

const express = require('express');
const path = require('path');

const app = express();
const modeloPath = path.join(__dirname, '../models/modelo_entrenado');

app.use('/', express.static(modeloPath));

const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Servidor del modelo escuchando en http://localhost:${PORT}`);
});
