// modules/servidor_modelo.js

const express = require('express');
const path = require('path');

const app = express();
const PUERTO = 3000;

// Ruta a la carpeta donde está el modelo entrenado
const carpetaModelo = path.join(__dirname, '../models/modelo_entrenado');

// Servir archivos estáticos del modelo
app.use(express.static(carpetaModelo));

app.get('/', (req, res) => {
  res.send('Servidor del modelo está corriendo. Visitá /model.json para cargar el modelo.');
});

app.listen(PUERTO, () => {
  console.log(`Servidor corriendo en http://localhost:${PUERTO}`);
});
