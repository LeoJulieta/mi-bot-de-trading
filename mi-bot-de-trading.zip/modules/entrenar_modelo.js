const tf = require('@tensorflow/tfjs');
const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

(async () => {
  try {
    // Paso 1: Ejecutar script para obtener datos reales
    console.log("Ejecutando script para obtener datos reales...");
    execSync('node modules/obtener_datos_reales.js', { stdio: 'inherit' });

    // Paso 2: Ejecutar script para procesar los datos
    console.log("Ejecutando script para procesar los datos...");
    execSync('node modules/procesar_datos.js', { stdio: 'inherit' });

    // Paso 3: Leer datos procesados
    const rutaDatos = path.join(__dirname, '../datasets/datos_procesados.json');
    const datosProcesados = JSON.parse(fs.readFileSync(rutaDatos, 'utf8'));

    // Paso 4: Preparar tensores de entrada y salida
    const entradas = datosProcesados.entradas;
    const salidas = datosProcesados.salidas;

    console.log("Ejemplo de entrada:", entradas[0]);
    console.log("Ejemplo de salida:", salidas[0]);

    const inputTensor = tf.tensor2d(entradas);
    const labelTensor = tf.tensor1d(salidas, 'int32');
    const oneHotLabels = tf.oneHot(labelTensor, 3);

    // Paso 5: Definir el modelo
    const model = tf.sequential();
    model.add(tf.layers.dense({ units: 32, activation: 'relu', inputShape: [entradas[0].length] }));
    model.add(tf.layers.dense({ units: 16, activation: 'relu' }));
    model.add(tf.layers.dense({ units: 3, activation: 'softmax' }));

    // Paso 6: Compilar el modelo
    model.compile({
      optimizer: tf.train.adam(),
      loss: 'categoricalCrossentropy',
      metrics: ['accuracy']
    });

    // Paso 7: Entrenar el modelo
    console.log("Entrenando el modelo...");
    await model.fit(inputTensor, oneHotLabels, {
      epochs: 50,
      shuffle: true,
      callbacks: {
        onEpochEnd: (epoch, logs) => {
          const loss = logs.loss.toFixed(4);
          const acc = (logs.acc * 100).toFixed(2);
          console.log(`Epoch ${epoch + 1}: pérdida=${loss}, precisión=${acc}%`);
        }
      }
    });

    // Paso 8: Guardar el modelo (modo compatible con Termux)
    console.log("Guardando el modelo...");

    const modeloDir = path.join(__dirname, '../models/modelo_entrenado');
    if (!fs.existsSync(modeloDir)) {
      fs.mkdirSync(modeloDir, { recursive: true });
    }

    await model.save(tf.io.withSaveHandler(async (modelArtifacts) => {
      const jsonPath = path.join(modeloDir, 'model.json');
      const weightsPath = path.join(modeloDir, 'weights.bin');

      fs.writeFileSync(jsonPath, JSON.stringify({
        modelTopology: modelArtifacts.modelTopology,
        weightsManifest: [{
          paths: ['weights.bin'],
          weights: modelArtifacts.weightSpecs
        }]
      }, null, 2));

      fs.writeFileSync(weightsPath, Buffer.from(modelArtifacts.weightData));

      console.log("Modelo guardado correctamente en:", modeloDir);
    }));

  } catch (error) {
    console.error('Error durante el entrenamiento:', error.message);
  }
})();
