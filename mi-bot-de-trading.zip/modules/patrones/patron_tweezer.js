function detectarTweezer(candles) {
  const patronesDetectados = [];

  for (let i = 1; i < candles.length; i++) {
    const prev = candles[i - 1];
    const curr = candles[i];

    const cuerpoPrev = Math.abs(prev.close - prev.open);
    const cuerpoCurr = Math.abs(curr.close - curr.open);

    const esAlcista = prev.high === curr.high && prev.close < prev.open && curr.close > curr.open;
    const esBajista = prev.low === curr.low && prev.close > prev.open && curr.close < curr.open;

    if ((esAlcista || esBajista) && cuerpoPrev > 0 && cuerpoCurr > 0) {
      patronesDetectados.push({
        tipo: esAlcista ? 'Tweezer Bottom' : 'Tweezer Top',
        indice: i,
        velas: [prev, curr]
      });

      console.log(`[${new Date().toISOString()}] Patrón detectado: ${esAlcista ? 'Tweezer Bottom' : 'Tweezer Top'} en velas ${i - 1} y ${i}`);
    }
  }

  return patronesDetectados;
}

module.exports = detectarTweezer;
