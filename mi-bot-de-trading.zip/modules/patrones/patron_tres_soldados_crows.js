function detectarTresSoldadosCrows(candles) {
  const patronesDetectados = [];

  for (let i = 2; i < candles.length; i++) {
    const vela1 = candles[i - 2];
    const vela2 = candles[i - 1];
    const vela3 = candles[i];

    // Lógica del patrón Three Soldiers / Three Crows va acá

    const cumpleCondicion = false;

    if (cumpleCondicion) {
      patronesDetectados.push({
        tipo: 'Three White Soldiers o Three Black Crows',
        indice: i,
        vela: vela3,
      });

      console.log(`[${new Date().toISOString()}] Patrón detectado: Three Soldiers/Crows en vela ${i}`);
    }
  }

  return patronesDetectados;
}

module.exports = detectarTresSoldadosCrows;
