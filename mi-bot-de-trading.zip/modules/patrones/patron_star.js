function detectarStar(candles) {
  const patronesDetectados = [];

  for (let i = 2; i < candles.length; i++) {
    const prev1 = candles[i - 2];
    const prev2 = candles[i - 1];
    const curr = candles[i];

    // Lógica del patrón Morning/Evening Star va acá

    const cumpleCondicion = false;

    if (cumpleCondicion) {
      patronesDetectados.push({
        tipo: 'Morning Star o Evening Star',
        indice: i,
        vela: curr,
      });

      console.log(`[${new Date().toISOString()}] Patrón detectado: Star en vela ${i}`);
    }
  }

  return patronesDetectados;
}

module.exports = detectarStar;
