// modules/patrones/patron_piercing_darkcloud.js

function detectarPiercingDarkCloud(candles) {
  const patronesDetectados = [];

  for (let i = 1; i < candles.length; i++) {
    const anterior = candles[i - 1];
    const actual = candles[i];

    const cuerpo = vela => Math.abs(vela.close - vela.open);
    const esBajista = anterior.close < anterior.open;
    const esAlcista = actual.close > actual.open;

    const mitadCuerpoAnterior = anterior.open - (cuerpo(anterior) / 2);

    // Piercing Line
    const esPiercing = (
      esBajista &&
      esAlcista &&
      actual.open < anterior.low &&
      actual.close > mitadCuerpoAnterior &&
      actual.close < anterior.open
    );

    // Dark Cloud Cover
    const esDarkCloud = (
      esAlcista &&
      esBajista &&
      actual.open > anterior.high &&
      actual.close < mitadCuerpoAnterior &&
      actual.close > anterior.open
    );

    if (esPiercing) {
      patronesDetectados.push({ tipo: 'Piercing Line', indice: i - 1 });
      console.log(`[${new Date().toISOString()}] Patrón detectado: Piercing Line en vela ${i - 1}`);
    } else if (esDarkCloud) {
      patronesDetectados.push({ tipo: 'Dark Cloud Cover', indice: i - 1 });
      console.log(`[${new Date().toISOString()}] Patrón detectado: Dark Cloud Cover en vela ${i - 1}`);
    }
  }

  return patronesDetectados;
}

module.exports = detectarPiercingDarkCloud;
