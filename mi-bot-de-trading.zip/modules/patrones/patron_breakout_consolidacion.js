// patron_breakout_consolidacion.js

function detectarBreakoutConsolidacion(velas) {
  const patrones = [];

  for (let i = 20; i < velas.length; i++) {
    const consolidacion = velas.slice(i - 10, i);
    const rango = Math.max(...consolidacion.map(v => v.high)) - Math.min(...consolidacion.map(v => v.low));

    if (rango / consolidacion[0].close < 0.01) {
      const breakout = velas[i];
      const direccion = breakout.close > consolidacion[9].high ? 'alcista' :
                        breakout.close < consolidacion[9].low ? 'bajista' : null;

      if (direccion) {
        patrones.push({
          tipo: 'Breakout de Consolidación',
          direccion,
          indice: i,
          timestamp: breakout.timestamp,
          resumen: `Breakout ${direccion} luego de consolidación de 10 velas.`
        });
      }
    }
  }

  return patrones;
}

module.exports = detectarBreakoutConsolidacion;
