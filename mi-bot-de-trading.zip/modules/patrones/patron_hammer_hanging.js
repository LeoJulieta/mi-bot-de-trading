function detectarHammerHanging(candles) {
  const patronesDetectados = [];

  for (let i = 0; i < candles.length; i++) {
    const vela = candles[i];

    // Lógica del patrón va acá

    const cumpleCondicion = false;

    if (cumpleCondicion) {
      patronesDetectados.push({
        tipo: 'Hammer o Hanging Man',
        indice: i,
        vela,
      });

      console.log(`[${new Date().toISOString()}] Patrón detectado: Hammer/Hanging Man en vela ${i}`);
    }
  }

  return patronesDetectados;
}

module.exports = detectarHammerHanging;
