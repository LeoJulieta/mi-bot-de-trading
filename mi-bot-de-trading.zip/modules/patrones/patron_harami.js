function detectarHarami(candles) {
  const patronesDetectados = [];

  for (let i = 1; i < candles.length; i++) {
    const prev = candles[i - 1];
    const curr = candles[i];

    // Lógica del patrón Harami va acá

    const cumpleCondicion = false;

    if (cumpleCondicion) {
      patronesDetectados.push({
        tipo: 'Harami',
        indice: i,
        vela: curr,
      });

      console.log(`[${new Date().toISOString()}] Patrón detectado: Harami en vela ${i}`);
    }
  }

  return patronesDetectados;
}

module.exports = detectarHarami;
