function detectarMarubozu(candles) {
  const patronesDetectados = [];

  for (let i = 0; i < candles.length; i++) {
    const vela = candles[i];
    const sinSombraSuperior = vela.high === Math.max(vela.open, vela.close);
    const sinSombraInferior = vela.low === Math.min(vela.open, vela.close);

    if (sinSombraSuperior && sinSombraInferior) {
      const tipo = vela.close > vela.open ? 'Marubozu Alcista' : 'Marubozu Bajista';

      patronesDetectados.push({ tipo, indice: i, vela });
      console.log(`[${new Date().toISOString()}] Patrón detectado: ${tipo} en vela ${i}`);
    }
  }

  return patronesDetectados;
}

module.exports = detectarMarubozu;
