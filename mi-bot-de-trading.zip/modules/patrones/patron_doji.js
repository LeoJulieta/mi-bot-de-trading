function detectarDoji(candles) {
  const patronesDetectados = [];

  for (let i = 0; i < candles.length; i++) {
    const vela = candles[i];
    const cuerpo = Math.abs(vela.close - vela.open);
    const rangoTotal = vela.high - vela.low;

    const esDoji = cuerpo <= rangoTotal * 0.1;
    if (!esDoji) continue;

    let tipo = 'Doji';

    const sombraSuperior = vela.high - Math.max(vela.close, vela.open);
    const sombraInferior = Math.min(vela.close, vela.open) - vela.low;

    if (sombraSuperior >= rangoTotal * 0.4 && sombraInferior >= rangoTotal * 0.4) {
      tipo = 'Doji Long-Legged';
    } else if (sombraSuperior <= rangoTotal * 0.1 && sombraInferior >= rangoTotal * 0.6) {
      tipo = 'Doji Dragonfly';
    } else if (sombraSuperior >= rangoTotal * 0.6 && sombraInferior <= rangoTotal * 0.1) {
      tipo = 'Doji Gravestone';
    }

    patronesDetectados.push({
      tipo,
      indice: i,
      vela
    });

    console.log(`[${new Date().toISOString()}] Patrón detectado: ${tipo} en vela ${i}`);
  }

  return patronesDetectados;
}

module.exports = detectarDoji;
