function detectar4CortesReversa(candles) {
  const patronesDetectados = [];

  for (let i = 5; i < candles.length; i++) {
    const sub = candles.slice(i - 5, i + 1); // 5 anteriores + vela actual

    let cortes = 0;
    let tendencia = null;

    for (let j = 1; j < 5; j++) {
      const anterior = sub[j - 1];
      const actual = sub[j];

      if (actual.close > anterior.close) {
        if (tendencia === 'baja') cortes++;
        tendencia = 'sube';
      } else if (actual.close < anterior.close) {
        if (tendencia === 'sube') cortes++;
        tendencia = 'baja';
      }
    }

    const velaReversa = sub[5];
    const velaAnterior = sub[4];

    const reversaAlcista = velaAnterior.close < velaAnterior.open && velaReversa.close > velaReversa.open;
    const reversaBajista = velaAnterior.close > velaAnterior.open && velaReversa.close < velaReversa.open;

    if (cortes >= 4 && (reversaAlcista || reversaBajista)) {
      patronesDetectados.push({
        tipo: reversaAlcista ? '4 Cortes + Reversa Alcista' : '4 Cortes + Reversa Bajista',
        indice: i,
        velas: sub.slice(1)
      });

      console.log(`[${new Date().toISOString()}] Patrón detectado: ${reversaAlcista ? '4 Cortes + Reversa Alcista' : '4 Cortes + Reversa Bajista'} en vela ${i}`);
    }
  }

  return patronesDetectados;
}

module.exports = detectar4CortesReversa;
