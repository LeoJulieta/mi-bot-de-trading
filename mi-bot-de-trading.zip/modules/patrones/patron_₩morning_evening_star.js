// modules/patrones/patron_morning_evening_star.js

function detectarMorningEveningStar(candles) {
  const patronesDetectados = [];

  for (let i = 2; i < candles.length; i++) {
    const vela1 = candles[i - 2];
    const vela2 = candles[i - 1];
    const vela3 = candles[i];

    const cuerpo1 = Math.abs(vela1.close - vela1.open);
    const cuerpo2 = Math.abs(vela2.close - vela2.open);
    const cuerpo3 = Math.abs(vela3.close - vela3.open);

    const esEstrella = cuerpo2 <= cuerpo1 * 0.3 && cuerpo2 <= cuerpo3 * 0.3;

    // Morning Star
    const esVela1Bajista = vela1.close < vela1.open;
    const esVela3Alcista = vela3.close > vela3.open;
    const gapAbajo = vela2.open < vela1.close && vela2.close < vela1.close;
    const cierreMayorInicio = vela3.close > vela1.open;

    const esMorningStar = esVela1Bajista && esEstrella && esVela3Alcista && gapAbajo && cierreMayorInicio;

    // Evening Star
    const esVela1Alcista = vela1.close > vela1.open;
    const esVela3Bajista = vela3.close < vela3.open;
    const gapArriba = vela2.open > vela1.close && vela2.close > vela1.close;
    const cierreMenorInicio = vela3.close < vela1.open;

    const esEveningStar = esVela1Alcista && esEstrella && esVela3Bajista && gapArriba && cierreMenorInicio;

    if (esMorningStar || esEveningStar) {
      const tipo = esMorningStar ? 'Morning Star' : 'Evening Star';

      patronesDetectados.push({
        tipo,
        indice: i,
        vela: vela3
      });

      console.log(`[${new Date().toISOString()}] Patrón detectado: ${tipo} en vela ${i}`);
    }
  }

  return patronesDetectados;
}

module.exports = detectarMorningEveningStar;
