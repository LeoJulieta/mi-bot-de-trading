// modules/patrones/patron_three_soldiers_crows.js

  function detectarThreeSoldiersCrows(candles) {
  const patronesDetectados = [];

  for (let i = 2; i < candles.length; i++) {
    const v1 = candles[i - 2];
    const v2 = candles[i - 1];
    const v3 = candles[i];

    // Cuerpos de las velas
    const cuerpo = vela => Math.abs(vela.close - vela.open);
    const esAlcista = vela => vela.close > vela.open;
    const esBajista = vela => vela.close < vela.open;

    // Three White Soldiers (tres soldados blancos)
    if (
      esAlcista(v1) && esAlcista(v2) && esAlcista(v3) &&
      v2.open > v1.open && v2.open < v1.close &&
      v3.open > v2.open && v3.open < v2.close &&
      cuerpo(v1) > 0 && cuerpo(v2) > 0 && cuerpo(v3) > 0
    ) {
      patronesDetectados.push({ tipo: 'Three White Soldiers', indice: i - 2 });
      console.log(`[${new Date().toISOString()}] Patrón detectado: Three White Soldiers en vela ${i - 2}`);
    }

    // Three Black Crows (tres cuervos negros)
    if (
      esBajista(v1) && esBajista(v2) && esBajista(v3) &&
      v2.open < v1.close && v2.open > v1.open &&
      v3.open < v2.close && v3.open > v2.open &&
      cuerpo(v1) > 0 && cuerpo(v2) > 0 && cuerpo(v3) > 0
    ) {
      patronesDetectados.push({ tipo: 'Three Black Crows', indice: i - 2 });
      console.log(`[${new Date().toISOString()}] Patrón detectado: Three Black Crows en vela ${i - 2}`);
    }
  }

  return patronesDetectados;
}

module.exports = detectarThreeSoldiersCrows;
