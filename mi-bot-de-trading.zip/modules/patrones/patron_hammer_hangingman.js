// modules/patrones/patron_hammer_hangingman.js

function detectarHammerHangingMan(candles) {
  const patronesDetectados = [];

  for (let i = 0; i < candles.length; i++) {
    const vela = candles[i];
    const cuerpo = Math.abs(vela.close - vela.open);
    const rango = vela.high - vela.low;

    if (rango === 0) continue; // evitar división por cero

    const sombraSuperior = vela.high - Math.max(vela.open, vela.close);
    const sombraInferior = Math.min(vela.open, vela.close) - vela.low;

    const esHammer = cuerpo <= rango * 0.3 && sombraInferior >= cuerpo * 2 && sombraSuperior <= cuerpo * 0.3;
    const esHangingMan = esHammer; // misma forma, contexto distinto

    if (esHammer || esHangingMan) {
      const tipo = (i > 0 && candles[i - 1].close < vela.close) ? 'Hammer' : 'Hanging Man';

      patronesDetectados.push({
        tipo,
        indice: i,
        vela
      });

      console.log(`[${new Date().toISOString()}] Patrón detectado: ${tipo} en vela ${i}`);
    }
  }

  return patronesDetectados;
}

module.exports = detectarHammerHangingMan;
