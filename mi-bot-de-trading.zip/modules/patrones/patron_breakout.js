function detectarBreakout(candles) {
  const patronesDetectados = [];

  for (let i = 5; i < candles.length; i++) {
    const consolidacion = candles.slice(i - 5, i);
    const maxPrevio = Math.max(...consolidacion.map(c => c.high));
    const minPrevio = Math.min(...consolidacion.map(c => c.low));

    const actual = candles[i];
    const esRompimientoAlcista = actual.close > maxPrevio;
    const esRompimientoBajista = actual.close < minPrevio;

    if (esRompimientoAlcista || esRompimientoBajista) {
      patronesDetectados.push({
        tipo: esRompimientoAlcista ? 'Breakout Alcista' : 'Breakout Bajista',
        indice: i,
        vela: actual,
        zonaPrev: { maxPrevio, minPrevio }
      });

      console.log(`[${new Date().toISOString()}] Patrón detectado: ${esRompimientoAlcista ? 'Breakout Alcista' : 'Breakout Bajista'} en vela ${i}`);
    }
  }

  return patronesDetectados;
}

module.exports = detectarBreakout;
