function detectarEngulfing(candles) {
  const patronesDetectados = [];

  for (let i = 1; i < candles.length; i++) {
    const prev = candles[i - 1];
    const curr = candles[i];

    // Lógica del patrón Engulfing va acá

    const cumpleCondicion = false;

    if (cumpleCondicion) {
      patronesDetectados.push({
        tipo: 'Engulfing',
        indice: i,
        vela: curr,
      });

      console.log(`[${new Date().toISOString()}] Patrón detectado: Engulfing en vela ${i}`);
    }
  }

  return patronesDetectados;
}

module.exports = detectarEngulfing;
