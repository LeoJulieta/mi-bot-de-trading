// modules/patrones/patron_morning_evening_star.js

function detectarMorningEveningStar(candles) {
  const patronesDetectados = [];

  for (let i = 2; i < candles.length; i++) {
    const vela1 = candles[i - 2];
    const vela2 = candles[i - 1];
    const vela3 = candles[i];

    const cuerpo1 = vela1.close - vela1.open;
    const cuerpo3 = vela3.close - vela3.open;

    // Morning Star (patrón alcista)
    if (
      vela1.close < vela1.open && // Vela bajista
      Math.abs(vela2.close - vela2.open) < Math.abs(cuerpo1) * 0.5 && // Pequeño cuerpo central
      vela3.close > vela3.open && // Vela alcista
      vela3.close > ((vela1.open + vela1.close) / 2) // Cierre por encima del punto medio de la primera
    ) {
      patronesDetectados.push({ tipo: 'Morning Star', indice: i - 2 });
      console.log(`[${new Date().toISOString()}] Patrón detectado: Morning Star en vela ${i - 2}`);
    }

    // Evening Star (patrón bajista)
    if (
      vela1.close > vela1.open && // Vela alcista
      Math.abs(vela2.close - vela2.open) < Math.abs(cuerpo1) * 0.5 && // Pequeño cuerpo central
      vela3.close < vela3.open && // Vela bajista
      vela3.close < ((vela1.open + vela1.close) / 2) // Cierre por debajo del punto medio de la primera
    ) {
      patronesDetectados.push({ tipo: 'Evening Star', indice: i - 2 });
      console.log(`[${new Date().toISOString()}] Patrón detectado: Evening Star en vela ${i - 2}`);
    }
  }

  return patronesDetectados;
}

module.exports = detectarMorningEveningStar;
