// validador_exports.cjs
const fs = require('fs');
const path = require('path');

const carpeta = __dirname; // carpeta actual donde están los patrones
const archivos = fs.readdirSync(carpeta).filter(f => f.endsWith('.js') && f !== 'validador_exports.cjs');

for (const archivo of archivos) {
  const ruta = path.join(carpeta, archivo);
  const contenido = fs.readFileSync(ruta, 'utf-8');

  const nombreFuncionMatch = contenido.match(/function\s+(detectar\w*)\s*
