// modules/verificar_archivos.cjs

const fs = require('fs');
const path = require('path');

// Ruta base del proyecto (ajustala si es necesario)
const BASE_DIR = path.resolve(__dirname, '..');

function verificarArchivos(rutasRelativas) {
    let todosExisten = true;

    rutasRelativas.forEach((rutaRelativa) => {
        const rutaCompleta = path.join(BASE_DIR, rutaRelativa);
        if (!fs.existsSync(rutaCompleta)) {
            console.error(`ERROR: El archivo requerido no existe: ${rutaCompleta}`);
            todosExisten = false;
        } else {
            console.log(`OK: Archivo encontrado: ${rutaCompleta}`);
        }
    });

    if (!todosExisten) {
        console.error("Faltan uno o más archivos necesarios. Abortando...");
        process.exit(1); // Finaliza el proceso con error
    }
}

module.exports = {
    verificarArchivos
};
