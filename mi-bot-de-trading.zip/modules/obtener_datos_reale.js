const fs = require('fs');
const path = require('path');
const https = require('https');

const url = 'https://api.binance.com/api/v3/klines?symbol=USDTBRL&interval=1m&limit=100';

https.get(url, res => {
  let data = '';

  res.on('data', chunk => { data += chunk; });
  res.on('end', () => {
    try {
      const rawCandles = JSON.parse(data);

      const processedCandles = rawCandles.map(candle => ({
        open: parseFloat(candle[1]),
        high: parseFloat(candle[2]),
        low: parseFloat(candle[3]),
        close: parseFloat(candle[4]),
        volume: parseFloat(candle[5])
      }));

      const outputPath = path.join(__dirname, '../datos/USDTBRL_ultimas.json');
      fs.writeFileSync(outputPath, JSON.stringify(processedCandles, null, 2));
      console.log(`Archivo guardado correctamente en ${outputPath}`);
    } catch (err) {
      console.error('Error al procesar la respuesta de Binance:', err);
    }
  });
}).on('error', err => {
  console.error('Error de conexión:', err);
});
