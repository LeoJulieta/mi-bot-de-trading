// modules/procesar_datos.js

const fs = require('fs');
const path = require('path');

// Función para loguear con timestamp
function log(mensaje) {
  const timestamp = new Date().toISOString();
  console.log(`[${timestamp}] ${mensaje}`);
}

// Parámetros de la ventana deslizante
const VENTANA = 5;

// Función principal
function main() {
  log('Iniciando procesamiento de datos...');

  // Rutas de archivos
  const rutaEntrada = path.join(__dirname, '..', 'datasets', 'datos_entrenamiento.json');
  const rutaSalida = path.join(__dirname, '..', 'datasets', 'datos_procesados.json');

  // Paso 1: Leer archivo de entrada
  let datosCrudos;
  try {
    datosCrudos = fs.readFileSync(rutaEntrada, 'utf8');
    log(`Archivo de entrada leído correctamente: ${rutaEntrada}`);
  } catch (error) {
    log(`Error al leer el archivo de entrada: ${error.message}`);
    process.exit(1);
  }

  // Paso 2: Parsear JSON y validar
  let velas;
  try {
    velas = JSON.parse(datosCrudos);
    if (!Array.isArray(velas) || velas.length < VENTANA + 2) {
      log('No hay suficientes velas para procesar. Se guardarán arrays vacíos.');
      const salidaVacia = { entradas: [], salidas: [] };
      fs.writeFileSync(rutaSalida, JSON.stringify(salidaVacia, null, 2));
      log(`Datos procesados guardados en: ${rutaSalida}`);
      return;
    }
    log(`Cantidad de velas disponibles: ${velas.length}`);
  } catch (error) {
    log(`Error al parsear el archivo JSON: ${error.message}`);
    process.exit(1);
  }

  // Paso 3: Procesar datos en entradas/salidas
  const entradas = [];
  const salidas = [];

  for (let i = VENTANA; i < velas.length - 1; i++) {
    const ventanaActual = velas.slice(i - VENTANA, i);
    const input = ventanaActual.flatMap(v => [
      v.open, v.high, v.low, v.close, v.volume
    ]);
    const output = velas[i + 1].close > velas[i].close ? 1 : 0;

    entradas.push(input);
    salidas.push(output);
  }

  // Paso 4: Guardar datos procesados
  const resultado = { entradas, salidas };
  try {
    fs.writeFileSync(rutaSalida, JSON.stringify(resultado, null, 2));
    log(`Datos procesados guardados en: ${rutaSalida}`);
    log(`Ejemplo de entrada: ${JSON.stringify(entradas[0])}`);
    log(`Ejemplo de salida: ${salidas[0]}`);
  } catch (error) {
    log(`Error al guardar el archivo procesado: ${error.message}`);
    process.exit(1);
  }

  log('Procesamiento de datos finalizado.');
}

// Ejecutar
main();
