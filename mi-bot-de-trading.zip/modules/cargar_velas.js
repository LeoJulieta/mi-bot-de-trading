const fs = require('fs');
const path = require('path');

function cargarVelasHistoricas() {
  const carpeta = 'datos';
  const archivos = fs.readdirSync(carpeta).filter(f => f.startsWith('velas-') && f.endsWith('.json'));

  let todas = [];
  for (const archivo of archivos) {
    const contenido = fs.readFileSync(path.join(carpeta, archivo), 'utf-8');
    try {
      todas = todas.concat(JSON.parse(contenido));
    } catch (e) {
      console.warn(`Error leyendo ${archivo}:`, e.message);
    }
  }

  return todas;
}

function cargarVelasRealtime() {
  const ruta = 'candles.json';
  if (!fs.existsSync(ruta)) throw new Error(`Archivo ${ruta} no encontrado. Ejecuta obtener_datos_reales.js primero.`);
  return JSON.parse(fs.readFileSync(ruta, 'utf-8'));
}

module.exports = { cargarVelasHistoricas, cargarVelasRealtime };
