// modules/generar_datos_entrenamiento.js

// ==============================
// Generar datos de entrenamiento
// ==============================

// Este script descarga 1440 velas (24hs) y prepara un archivo JSON con esos datos listos para entrenar

const fs = require('fs');
const path = require('path');
const axios = require('axios');

// Configuración
const simbolo = 'USDTBRL';
const intervalo = '1m'; // 1 minuto
const limite = 1000; // Binance solo permite 1000 por vez
const cantidadDeseada = 1440; // 24 horas

// Función principal
(async () => {
  console.log('Descargando velas...');
  let todasLasVelas = [];

  // Paso 1: Descargar las primeras 1000
  const respuesta1 = await axios.get(`https://api.binance.com/api/v3/klines?symbol=${simbolo}&interval=${intervalo}&limit=1000`);
  todasLasVelas.push(...respuesta1.data);

  // Paso 2: Descargar las siguientes 440
  const ultimaFecha = respuesta1.data[respuesta1.data.length - 1][0];
  const respuesta2 = await axios.get(`https://api.binance.com/api/v3/klines?symbol=${simbolo}&interval=${intervalo}&limit=440&startTime=${ultimaFecha + 60_000}`);
  todasLasVelas.push(...respuesta2.data);

  // Paso 3: Formatear los datos
  const datosFormateados = todasLasVelas.map(vela => {
    const [timestamp, open, high, low, close, volume] = vela;
    const resultado = parseFloat(close) > parseFloat(open) ? 1 : 0; // Subió = 1, Bajó = 0
    return {
      timestamp,
      open: parseFloat(open),
      high: parseFloat(high),
      low: parseFloat(low),
      close: parseFloat(close),
      volume: parseFloat(volume),
      resultado
    };
  });

  // Paso 4: Guardar archivo JSON
  const ruta = path.join(__dirname, '../datos/USDTBRL_entrenamiento.json');
  fs.writeFileSync(ruta, JSON.stringify(datosFormateados, null, 2));
  console.log('Archivo generado correctamente en', ruta);
})();
