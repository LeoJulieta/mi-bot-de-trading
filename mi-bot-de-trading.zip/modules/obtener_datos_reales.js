// Módulos necesarios
const fs = require('fs');
const path = require('path');
const https = require('https');

// Paso 1: Definir parámetros de la solicitud
const simbolo = 'USDTBRL';
const intervalo = '1m'; // 1 minuto
const limite = 1440; // 1440 velas = 24 horas

// Paso 2: Construir URL de la API de Binance
const url = `https://api.binance.com/api/v3/klines?symbol=${simbolo}&interval=${intervalo}&limit=${limite}`;

// Paso 3: Hacer la solicitud HTTPS
https.get(url, (res) => {
  let data = '';

  // Paso 4: Acumular datos recibidos
  res.on('data', (chunk) => {
    data += chunk;
  });

  // Paso 5: Al finalizar la recepción de datos
  res.on('end', () => {
    try {
      // Paso 6: Parsear los datos a JSON
      const velas = JSON.parse(data);

      // Paso 7: Transformar las velas al formato deseado
      const datos = velas.map((vela) => {
        return {
          open: parseFloat(vela[1]),
          high: parseFloat(vela[2]),
          low: parseFloat(vela[3]),
          close: parseFloat(vela[4]),
          volume: parseFloat(vela[5])
        };
      });

      // Paso 8: Asegurarse de que la carpeta 'datasets' exista
      const datasetsPath = path.join(__dirname, '../datasets');
      if (!fs.existsSync(datasetsPath)) {
        fs.mkdirSync(datasetsPath);
      }

      // Paso 9: Guardar los datos como JSON en 'datasets/datos_entrenamiento.json'
      const ruta = path.join(datasetsPath, 'datos_entrenamiento.json');
      fs.writeFileSync(ruta, JSON.stringify(datos, null, 2));

      // Paso 10: Mostrar mensaje de éxito
      console.log(`Archivo guardado correctamente en ${ruta}`);
    } catch (error) {
      console.error('Error al procesar los datos:', error.message);
    }
  });
}).on('error', (error) => {
  console.error('Error al obtener los datos:', error.message);
});
