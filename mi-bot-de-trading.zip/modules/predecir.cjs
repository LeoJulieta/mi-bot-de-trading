// modules/predecir.cjs

const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');
const axios = require('axios');

// Configuración general
const RUTA_DATOS_PROCESADOS = path.join(__dirname, '../datasets/datos_procesados.json');
const RUTA_RESULTADOS_CSV = path.join(__dirname, '../resultados/predicciones.csv');
const RUTA_LOGS = path.join(__dirname, '../logs/');
const SOCKET_TMUX = '/data/data/com.termux/files/usr/tmp/tmux_socket';
const SERVIDOR_SCRIPT = 'modules/servidor_modelo.cjs';
const SESION_TMUX = 'modelo_server';
const URL_PREDICCION = 'http://localhost:3000/predict';

// Utilidad para logs con timestamp
function log(mensaje) {
  const timestamp = new Date().toISOString();
  const logFinal = `[${timestamp}] ${mensaje}`;
  console.log(logFinal);

  if (!fs.existsSync(RUTA_LOGS)) {
    fs.mkdirSync(RUTA_LOGS, { recursive: true });
  }

  const logPath = path.join(RUTA_LOGS, 'prediccion.log');
  fs.appendFileSync(logPath, logFinal + '\n');
}

// Ejecutar un script con Node.js
function ejecutarScript(ruta) {
  return new Promise((resolve, reject) => {
    log(`Ejecutando script: ${ruta}`);
    const proceso = spawn('node', [ruta]);

    proceso.stdout.on('data', data => process.stdout.write(data));
    proceso.stderr.on('data', data => process.stderr.write(data));

    proceso.on('close', codigo => {
      if (codigo === 0) resolve();
      else reject(new Error(`El script ${ruta} terminó con código ${codigo}`));
    });
  });
}

// Verificar si el servidor está respondiendo
async function servidorResponde() {
  try {
    await axios.get('http://localhost:3000/');
    return true;
  } catch {
    return false;
  }
}

// Esperar a que el servidor esté disponible
async function esperarServidor(reintentos = 20, intervaloMs = 1000) {
  for (let i = 1; i <= reintentos; i++) {
    log(`Esperando al servidor del modelo... (${i}/${reintentos})`);
    if (await servidorResponde()) return true;
    await new Promise(r => setTimeout(r, intervaloMs));
  }
  return false;
}

// Iniciar el servidor del modelo en segundo plano con tmux
function iniciarServidor() {
  return new Promise((resolve, reject) => {
    log('Servidor no activo. Iniciando servidor en segundo plano con tmux...');
    const comando = `tmux -S ${SOCKET_TMUX} new-session -d -s ${SESION_TMUX} 'node ${SERVIDOR_SCRIPT}'`;
    const proceso = spawn('sh', ['-c', comando]);

    proceso.on('close', codigo => {
      if (codigo === 0) resolve();
      else reject(new Error(`No se pudo iniciar el servidor con tmux (código ${codigo})`));
    });
  });
}

// Detener el servidor si fue iniciado por este script
function detenerServidor() {
  return new Promise((resolve) => {
    log('Deteniendo servidor del modelo...');
    const comando = `tmux -S ${SOCKET_TMUX} kill-session -t ${SESION_TMUX}`;
    spawn('sh', ['-c', comando]).on('close', () => resolve());
  });
}

// Función principal
async function main() {
  try {
    log('Iniciando predicción...');

    // Paso 1: Ejecutar módulos auxiliares
    await ejecutarScript('modules/obtener_datos_reales.js');
    await ejecutarScript('modules/procesar_datos.js');

    // Paso 2: Cargar datos procesados
    const datos = JSON.parse(fs.readFileSync(RUTA_DATOS_PROCESADOS, 'utf8'));
    const entradas = datos.entradas || [];

    log(`Cantidad de entradas para predecir: ${entradas.length}`);
    if (!entradas.length) throw new Error('No hay entradas para predecir');

    // Paso 3: Verificar servidor
    let servidorActivo = await servidorResponde();
    let iniciadoPorEsteScript = false;

    if (!servidorActivo) {
      await iniciarServidor();
      iniciadoPorEsteScript = true;
      const disponible = await esperarServidor();
      if (!disponible) throw new Error('Servidor no respondió a tiempo');
    }

    // Paso 4: Predecir
    const predicciones = [];
    for (let i = 0; i < entradas.length; i++) {
      const entrada = entradas[i];
      try {
        const respuesta = await axios.post(URL_PREDICCION, { input: entrada });
        const prediccion = respuesta.data.output;
        predicciones.push({ entrada, prediccion });
      } catch (error) {
        log(`Error al predecir entrada ${i}: ${error.message}`);
      }
    }

    // Paso 5: Guardar resultados en CSV
    if (!fs.existsSync(path.dirname(RUTA_RESULTADOS_CSV))) {
      fs.mkdirSync(path.dirname(RUTA_RESULTADOS_CSV), { recursive: true });
    }

    const filasCSV = predicciones.map(p =>
      `${new Date().toISOString()},${p.entrada.join(';')},${p.prediccion}`
    ).join('\n');

    fs.appendFileSync(RUTA_RESULTADOS_CSV, filasCSV + '\n');
    log(`Predicciones guardadas en: ${RUTA_RESULTADOS_CSV}`);

    // Paso 6: Apagar servidor si fue iniciado por este script
    if (iniciadoPorEsteScript) {
      await detenerServidor();
      log('Servidor apagado correctamente.');
    }

    log('Predicción finalizada con éxito.');
  } catch (error) {
    log(`Error en predicción: ${error.message}`);
    process.exit(1);
  }
}

main();
