const fs = require("fs");
const Papa = require("papaparse");

const rutaCSV = "./data/datos_historicos.csv";
const rutaSalida = "./data/dataset_procesado.json";

const contenidoCSV = fs.readFileSync(rutaCSV, "utf8");

const { data, errors } = Papa.parse(contenidoCSV, {
  header: true,
  dynamicTyping: true,
  skipEmptyLines: true
});

if (errors.length > 0) {
  console.error("Errores al parsear el CSV:", errors);
  process.exit(1);
}

// Convertimos y normalizamos
const features = [];
const precios = data.map(row => ({
  apertura: row.precio_apertura,
  maximo: row.precio_maximo,
  minimo: row.precio_minimo,
  cierre: row.precio_cierre
}));

// Calcular min y max por cada columna
const columnas = ["apertura", "maximo", "minimo", "cierre"];
const stats = {};
columnas.forEach(col => {
  const valores = precios.map(p => p[col]);
  stats[col] = {
    min: Math.min(...valores),
    max: Math.max(...valores)
  };
});

// Normalizar
precios.forEach(p => {
  const f = columnas.map(col => {
    const { min, max } = stats[col];
    return (p[col] - min) / (max - min);
  });
  features.push(f);
});

// Dividir features y etiquetas (usamos 'cierre' del próximo paso como etiqueta)
const X = features.slice(0, -1);
const y = features.slice(1).map(f => f[3]); // índice 3 = cierre

const datasetFinal = { X, y };

fs.writeFileSync(rutaSalida, JSON.stringify(datasetFinal, null, 2), "utf8");

console.log("RESULTADO: Dataset procesado y guardado como JSON.");
