// modules/procesar_datos_entrenamiento.js

const fs = require('fs');
const path = require('path');

// Ruta del archivo de velas crudas
const archivoVelas = path.join(__dirname, '../datos/USDTBRL_velas_crudas.json');

// Ruta de salida
const archivoSalida = path.join(__dirname, '../datos/USDTBRL_entrenamiento.json');

try {
  console.log("Leyendo velas crudas...");
  const contenido = fs.readFileSync(archivoVelas, 'utf8');
  const velas = JSON.parse(contenido);

  console.log("Cantidad de velas:", velas.length);

  const datosProcesados = [];

  // Usamos todas menos la última vela para evitar desbordes
  for (let i = 0; i < velas.length - 1; i++) {
    const actual = velas[i];
    const siguiente = velas[i + 1];

    // Creamos el input
    const input = [actual.open, actual.high, actual.low, actual.close, actual.volume];

    // Definimos el output según si el precio sube o no en la próxima vela
    const output = siguiente.close > actual.close ? 1 : 0;

    datosProcesados.push({ input, output });
  }

  fs.writeFileSync(archivoSalida, JSON.stringify(datosProcesados, null, 2));
  console.log("Archivo procesado guardado correctamente en:", archivoSalida);

} catch (error) {
  console.error("Error al procesar los datos:", error.message);
}
