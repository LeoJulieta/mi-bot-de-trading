# Proyecto: Mi bot de trading

Última actualización: Tue Apr 22 19:02:00 -03 2025

## Estructura de carpetas
.
├── README.md
├── Sclean.sh
├── actualizarVelas.js
├── actualizar_historico.js
├── analizarConMartingala.js
├── anotadorBitacora.txt
├── anotadorBitacora.txt.save
├── asociar_datos_vela.js
├── autoentrenador.js
├── autolog.sh
├── autoupdater.sh
├── backtest.js
├── backtest.json
├── backups
│   ├── backup-2025-04-22_15-52.zip
│   ├── backup-2025-04-22_16-03.zip
│   ├── backup-2025-04-22_16-27.zip
│   └── backup-2025-04-22_18-01.zip
├── backups_modelo
├── bot-inteligente.js
├── bot-simulacion-corregido-FIXED.js
├── bot-simulacion-corregido.js
├── bot-simulacion.js
├── bot.js
├── botSimulacionF.js
├── bot_actual_mal.js
├── bot_martingala.zip
├── bot_martingala_v2.zip
├── bot_simulacion.js
├── botsimulacionf
├── candles.json
├── chatgpt.sh
├── chatlog.md
├── convertir_a_datos_entrenamiento.js
├── convertir_resultados.js
├── data
│   ├── USDTBRL_1m.json
│   ├── dataset_entrenamiento.json
│   ├── dataset_procesado.json
│   ├── datos_historicos.csv
│   ├── descargar_velas.js
│   ├── historical.json
│   ├── velas.json
│   └── verificar_cantidad.js
├── dataset_entrenamiento.json
├── dataset_entrenamiento_limpio.json
├── dataset_operaciones.csv
├── datasets
│   ├── datos_entrenamiento.json
│   ├── datos_entrenamiento_prueba.json
│   └── datos_procesados.json
├── datos
│   ├── USDTBRL_entrenamiento.json
│   ├── USDTBRL_ultimas.json
│   ├── USDTBRL_velas_crudas.json
│   ├── datos.json
│   ├── descargarVelas.json
│   ├── resultados.json
│   ├── velas-2025-04-01.json
│   ├── velas-2025-04-02.json
│   ├── velas-2025-04-03.json
│   ├── velas-2025-04-04.json
│   ├── velas-2025-04-05.json
│   ├── velas-2025-04-06.json
│   ├── velas-2025-04-07.json
│   ├── velas-2025-04-08.json
│   ├── velas-2025-04-09.json
│   ├── velas-2025-04-10.json
│   ├── velas-2025-04-11.json
│   ├── velas-2025-04-12.json
│   ├── velas-2025-04-13.json
│   ├── velas-2025-04-14.json
│   ├── velas-2025-04-15.json
│   ├── velas-2025-04-16.json
│   └── velas.json
├── datos.json
├── datos_entrenamiento_prueba.json
├── depurar_dataset.js
├── descargarVelas.js
├── descargarVelass.js
├── descargar_por_fecha.js
├── detectarPatron.js
├── detectar_patrones.cjs
├── download.js
├── entrenamiento-programado.js
├── entrenamiento.js
├── entrenamiento.zip
├── entrenamiento_120d.zip
├── entrenamiento_con_mas_patrones.zip
├── entrenar_modelo_incremental.js
├── entrenar_y_backtestear.js
├── escaner.js
├── estado_patrones.json
├── estructura_proyecto.txt
├── evaluadorEfectividad.js
├── evaluar_resultado_de_patrones.js
├── fetchCandles.js
├── generar_dataset_csv.js
├── gestorPatrones.js
├── gestor_patrones.js
├── historico.json
├── index.js
├── indicadores.js
├── limpiar_dataset.js
├── log-dashboard.html
├── logs
│   ├── autolog.log
│   ├── deteccion_patrones.log
│   ├── detectar_patrones.log
│   ├── entrenamiento.log
│   ├── git.log
│   ├── input_para_chatgpt.json
│   ├── last_backup_time.txt
│   ├── ls-scan.json
│   ├── mapa_archivos.json
│   ├── operaciones_log.txt
│   ├── pipeline.log
│   ├── predecir.log
│   └── prediccion.log
├── memoria.json
├── ml.js
├── modelo_entrenado
│   ├── model.json
│   └── weights.bin
├── modelo_entrenado.json
├── models
│   └── modelo_entrenado
├── modules
│   ├── cargar_velas.js
│   ├── entrenar_modelo.js
│   ├── generar_datos_entrenamiento.js
│   ├── obtener_datos_reale.js
│   ├── obtener_datos_reales.js
│   ├── patrones
│   ├── predecir.cjs
│   ├── preparar_datos.js
│   ├── procesar_datos.js
│   ├── procesar_datos_entrenamiento.js
│   ├── servidor_modelo.cjs
│   ├── servidor_modelo.js
│   └── verificar_archivos.cjs
├── modwls
├── node_modules
│   ├── @cypress
│   ├── @streamparser
│   ├── @telegraf
│   ├── @tensorflow
│   ├── @types
│   ├── @webgpu
│   ├── abort-controller
│   ├── accepts
│   ├── ajv
│   ├── ansi-regex
│   ├── ansi-styles
│   ├── argparse
│   ├── array-buffer-byte-length
│   ├── array.prototype.findindex
│   ├── arraybuffer.prototype.slice
│   ├── asn1
│   ├── assert-plus
│   ├── async-function
│   ├── asynckit
│   ├── available-typed-arrays
│   ├── aws-sign2
│   ├── aws4
│   ├── axios
│   ├── bcrypt-pbkdf
│   ├── bl
│   ├── bluebird
│   ├── body-parser
│   ├── buffer-alloc
│   ├── buffer-alloc-unsafe
│   ├── buffer-fill
│   ├── bytes
│   ├── call-bind
│   ├── call-bind-apply-helpers
│   ├── call-bound
│   ├── caseless
│   ├── chalk
│   ├── cliui
│   ├── color-convert
│   ├── color-name
│   ├── combined-stream
│   ├── commander
│   ├── content-disposition
│   ├── content-type
│   ├── cookie
│   ├── cookie-signature
│   ├── core-js
│   ├── core-util-is
│   ├── cors
│   ├── dashdash
│   ├── data-view-buffer
│   ├── data-view-byte-length
│   ├── data-view-byte-offset
│   ├── debug
│   ├── define-data-property
│   ├── define-properties
│   ├── delayed-stream
│   ├── depd
│   ├── dotenv
│   ├── dunder-proto
│   ├── ecc-jsbn
│   ├── ee-first
│   ├── emoji-regex
│   ├── encodeurl
│   ├── end-of-stream
│   ├── es-abstract
│   ├── es-define-property
│   ├── es-errors
│   ├── es-object-atoms
│   ├── es-set-tostringtag
│   ├── es-shim-unscopables
│   ├── es-to-primitive
│   ├── escalade
│   ├── escape-html
│   ├── etag
│   ├── event-target-shim
│   ├── eventemitter3
│   ├── express
│   ├── extend
│   ├── extsprintf
│   ├── fast-deep-equal
│   ├── fast-json-stable-stringify
│   ├── file-type
│   ├── finalhandler
│   ├── follow-redirects
│   ├── for-each
│   ├── forever-agent
│   ├── form-data
│   ├── forwarded
│   ├── fresh
│   ├── function-bind
│   ├── function.prototype.name
│   ├── functions-have-names
│   ├── get-caller-file
│   ├── get-intrinsic
│   ├── get-proto
│   ├── get-symbol-description
│   ├── getpass
│   ├── globalthis
│   ├── gopd
│   ├── har-schema
│   ├── har-validator
│   ├── has-bigints
│   ├── has-flag
│   ├── has-property-descriptors
│   ├── has-proto
│   ├── has-symbols
│   ├── has-tostringtag
│   ├── hasown
│   ├── http-errors
│   ├── http-signature
│   ├── iconv-lite
│   ├── inherits
│   ├── internal-slot
│   ├── ipaddr.js
│   ├── is-array-buffer
│   ├── is-async-function
│   ├── is-bigint
│   ├── is-boolean-object
│   ├── is-callable
│   ├── is-data-view
│   ├── is-date-object
│   ├── is-finalizationregistry
│   ├── is-fullwidth-code-point
│   ├── is-generator-function
│   ├── is-map
│   ├── is-number-object
│   ├── is-promise
│   ├── is-regex
│   ├── is-set
│   ├── is-shared-array-buffer
│   ├── is-string
│   ├── is-symbol
│   ├── is-typed-array
│   ├── is-typedarray
│   ├── is-weakmap
│   ├── is-weakref
│   ├── is-weakset
│   ├── isarray
│   ├── isstream
│   ├── jsbn
│   ├── json-schema
│   ├── json-schema-traverse
│   ├── json-stringify-safe
│   ├── json2csv
│   ├── jsprim
│   ├── lodash
│   ├── lodash.get
│   ├── long
│   ├── math-intrinsics
│   ├── media-typer
│   ├── merge-descriptors
│   ├── mime
│   ├── mime-db
│   ├── mime-types
│   ├── mri
│   ├── ms
│   ├── negotiator
│   ├── node-fetch
│   ├── node-telegram-bot-api
│   ├── oauth-sign
│   ├── object-assign
│   ├── object-inspect
│   ├── object-keys
│   ├── object.assign
│   ├── on-finished
│   ├── once
│   ├── own-keys
│   ├── p-timeout
│   ├── papaparse
│   ├── parseurl
│   ├── path-to-regexp
│   ├── performance-now
│   ├── possible-typed-array-names
│   ├── process-nextick-args
│   ├── proxy-addr
│   ├── proxy-from-env
│   ├── psl
│   ├── pump
│   ├── punycode
│   ├── qs
│   ├── querystringify
│   ├── range-parser
│   ├── raw-body
│   ├── readable-stream
│   ├── reflect.getprototypeof
│   ├── regenerator-runtime
│   ├── regexp.prototype.flags
│   ├── request
│   ├── request-promise-core
│   ├── require-directory
│   ├── requires-port
│   ├── router
│   ├── safe-array-concat
│   ├── safe-buffer
│   ├── safe-compare
│   ├── safe-push-apply
│   ├── safe-regex-test
│   ├── safer-buffer
│   ├── sandwich-stream
│   ├── seedrandom
│   ├── send
│   ├── serve-static
│   ├── set-function-length
│   ├── set-function-name
│   ├── set-proto
│   ├── setprototypeof
│   ├── side-channel
│   ├── side-channel-list
│   ├── side-channel-map
│   ├── side-channel-weakmap
│   ├── sprintf-js
│   ├── sshpk
│   ├── statuses
│   ├── stealthy-require
│   ├── string-width
│   ├── string.prototype.trim
│   ├── string.prototype.trimend
│   ├── string.prototype.trimstart
│   ├── string_decoder
│   ├── strip-ansi
│   ├── supports-color
│   ├── telegraf
│   ├── tldts
│   ├── tldts-core
│   ├── toidentifier
│   ├── tough-cookie
│   ├── tr46
│   ├── tunnel-agent
│   ├── tweetnacl
│   ├── type-is
│   ├── typed-array-buffer
│   ├── typed-array-byte-length
│   ├── typed-array-byte-offset
│   ├── typed-array-length
│   ├── unbox-primitive
│   ├── undici-types
│   ├── universalify
│   ├── unpipe
│   ├── uri-js
│   ├── url-parse
│   ├── util-deprecate
│   ├── uuid
│   ├── vary
│   ├── verror
│   ├── webidl-conversions
│   ├── whatwg-url
│   ├── which-boxed-primitive
│   ├── which-builtin-type
│   ├── which-collection
│   ├── which-typed-array
│   ├── wrap-ansi
│   ├── wrappy
│   ├── y18n
│   ├── yargs
│   └── yargs-parser
├── package-lock.json
├── package.json
├── packaje.json
├── patrones.js
├── patrones.json
├── patrones_con_datos_de_vela.json
├── patrones_detectados.json
├── patrones_detectados_historial.json
├── pipeline.js
├── pipeline_entrenamiento.js
├── predecir_con_modelo.js
├── predicciones
│   └── resultados.csv
├── predict.js
├── registro.log
├── registroOperaciones.js
├── registroResultados.js
├── resultados
│   ├── patrones_detectados.json
│   ├── resultados-2025-04-07.json
│   ├── resultados-2025-04-08.json
│   ├── resultados-2025-04-09.json
│   ├── resultados-2025-04-10.json
│   ├── resultados-2025-04-11.json
│   ├── resultados-2025-04-13.json
│   ├── resultados-2025-04-14.json
│   ├── resultados-2025-04-16.json
│   ├── resultados.csv
│   ├── resultados.json
│   ├── resultados.log
│   └── resumen-backtest.json
├── resultadosBotF
│   ├── 2025-04-01.csv
│   ├── 2025-04-01.json
│   ├── 2025-04-01.log
│   ├── 2025-04-02.csv
│   ├── 2025-04-02.json
│   ├── 2025-04-02.log
│   ├── 2025-04-03.csv
│   ├── 2025-04-03.json
│   ├── 2025-04-03.log
│   ├── 2025-04-04.csv
│   ├── 2025-04-04.json
│   ├── 2025-04-04.log
│   ├── 2025-04-05.csv
│   ├── 2025-04-05.json
│   └── 2025-04-05.log
├── resultados_convertidos.json
├── resultados_convertidos_limpio.json
├── resultados_evaluados.json
├── resultados_patrones.json
├── resultados_simulacion.json
├── resumenes
│   ├── 2025-04-13-resumen.md
│   ├── 2025-04-14-resumen.md
│   ├── 2025-04-15-resumen.md
│   ├── 2025-04-16-resumen.md
│   ├── 2025-04-17-resumen.md
│   ├── 2025-04-18-resumen.md
│   ├── 2025-04-19-resumen.md
│   ├── 2025-04-20-resumen.md
│   ├── 2025-04-21-resumen.md
│   └── 2025-04-22-resumen.md
├── scripts
│   ├── asociar_datos_vela.js
│   ├── evaluar_resultado_de_patrones.js
│   ├── limpiar_dataset.js
│   └── limpiar_resultados.js
├── sedassi-ml
│   └── modules
├── sedassi_telegram_bot.js
├── server.js
├── telegram
│   ├── index.js
│   ├── notificar.js
│   └── sedassibot.js
├── telegram_bot.js
├── tools
│   ├── Organizador.js
│   ├── autolog.sh
│   ├── backup.sh
│   ├── chatgpt.sh
│   └── ls-scan.js
├── usar_modelo_entrenado.js
├── ver_patrones_en_consola.js
└── version-estable-bot-v1.txt

279 directories, 206 files

## Últimos cambios
- 5b90d11 Primera parte del push segmentado (2025-04-22 18:54:00 -0300)
- 1c6e58e Primera subida del bot (2025-04-22 18:00:38 -0300)
- 70daf7e Auto backup y sincronización: 2025-04-17 20:00:00 (2025-04-17 20:01:52 -0300)
## Estado del repositorio remoto
Todo sincronizado con el repositorio remoto.

