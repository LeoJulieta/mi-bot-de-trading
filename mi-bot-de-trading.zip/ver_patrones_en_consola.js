// ver_patrones_en_consola.js
const fs = require('fs');

// Leer archivo JSON
const resultados = JSON.parse(fs.readFileSync('resultados_patrones.json', 'utf8'));

// Mostrar cada patrón con su tipo e índice
resultados.forEach((patron, i) => {
  console.log(`#${i + 1} Patrón detectado: ${patron.tipo} en índice ${patron.indice}`);
  const vela = patron.vela;
  if (vela) {
    console.log(`  Vela: O=${vela.open}, H=${vela.high}, L=${vela.low}, C=${vela.close}, Time=${new Date(vela.timestamp).toLocaleString()}`);
  }
});
