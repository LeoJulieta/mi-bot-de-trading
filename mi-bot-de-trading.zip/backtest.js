const tf = require('@tensorflow/tfjs');
const fs = require('fs');

const velas = JSON.parse(fs.readFileSync('./data/USDTBRL_1m.json', 'utf8'));

const datosEntrada = [];
const datosSalida = [];

for (let i = 50; i < velas.length - 1; i++) {
  const subarray = velas.slice(i - 50, i).map(v => parseFloat(v.close));
  const siguiente = parseFloat(velas[i + 1].close);
  const actual = parseFloat(velas[i].close);
  const label = siguiente > actual ? 1 : 0;

  datosEntrada.push(subarray);
  datosSalida.push(label);
}

const xs = tf.tensor2d(datosEntrada);
const ys = tf.tensor2d(datosSalida, [datosSalida.length, 1]);

const modelo = tf.sequential();
modelo.add(tf.layers.dense({ units: 64, activation: 'relu', inputShape: [50] }));
modelo.add(tf.layers.dense({ units: 32, activation: 'relu' }));
modelo.add(tf.layers.dense({ units: 1, activation: 'sigmoid' }));

modelo.compile({
  optimizer: 'adam',
  loss: 'binaryCrossentropy',
  metrics: ['accuracy']
});

(async () => {
  await modelo.fit(xs, ys, {
    epochs: 5,
    batchSize: 32,
    verbose: 1
  });

  console.log('Modelo entrenado');

  // Inicia backtest con lógica real
  let balance = 5; // USDT inicial
  let inversion = 1;
  let ganadas = 0;
  let perdidas = 0;

  for (let i = 50; i < velas.length - 1; i++) {
    const secuencia = velas.slice(i - 50, i).map(v => parseFloat(v.close));
    const actual = parseFloat(velas[i].close);
    const siguiente = parseFloat(velas[i + 1].close);

    const input = tf.tensor2d([secuencia]);
    const pred = await modelo.predict(input).data();
    const decision = pred[0] > 0.5 ? 'alza' : 'baja';

    const resultado =
      (decision === 'alza' && siguiente > actual) ||
      (decision === 'baja' && siguiente < actual);

    if (resultado) {
      balance += inversion * 0.85; // Ganancia estimada 85%
      inversion = 1;
      ganadas++;
    } else {
      balance -= inversion;
      inversion *= 2; // Martingala
      perdidas++;
      if (inversion > balance) inversion = 1; // Evita quiebra
    }
  }

  console.log('\n=== RESULTADOS ===');
  console.log('Balance final: $' + balance.toFixed(2));
  console.log('Ganadas:', ganadas);
  console.log('Perdidas:', perdidas);
})();
