// simulacion.js

const fs = require('fs');
const path = require('path');

// CONFIGURACIÓN
const archivoDatos = path.join(__dirname, 'data', 'USDTBRL-1m.json');
const fechaObjetivo = '2025-04-10'; // Fecha a testear (YYYY-MM-DD)
const montoInicial = 5;

// Lógica de la estrategia personalizada (ejemplo simplificado)
function aplicarEstrategia(velas) {
  let balance = montoInicial;
  let operaciones = 0;
  let ganadas = 0;
  let perdidas = 0;

  for (let i = 5; i < velas.length; i++) {
    const velaActual = velas[i];
    const cierre = parseFloat(velaActual.close);

    // Estrategia: si las 3 velas anteriores fueron bajistas, comprar y vender en la siguiente
    const bajistas = velas.slice(i - 3, i).every(v => parseFloat(v.close) < parseFloat(v.open));
    if (bajistas) {
      const entrada = cierre;
      const salida = parseFloat(velas[i + 1]?.close || cierre);

      const resultado = salida > entrada ? 0.2 : -0.2; // Resultado fijo simplificado
      balance += resultado;
      operaciones++;
      if (resultado > 0) ganadas++;
      else perdidas++;
    }
  }

  return { balance, operaciones, ganadas, perdidas };
}

// Leer el archivo y filtrar por fecha
function obtenerVelasPorFecha(fecha) {
  const raw = fs.readFileSync(archivoDatos);
  const data = JSON.parse(raw);
  return data.filter(v => v.time.startsWith(fecha));
}

function ejecutarSimulacion() {
  const velas = obtenerVelasPorFecha(fechaObjetivo);
  console.log(`Velas encontradas para ${fechaObjetivo}: ${velas.length}`);
  if (velas.length === 0) return console.log('No se encontraron velas para esa fecha.');

  const resultado = aplicarEstrategia(velas);

  console.log('\n--- Resultados del Backtest ---');
  console.log(`Fecha: ${fechaObjetivo}`);
  console.log(`Operaciones: ${resultado.operaciones}`);
  console.log(`Ganadas: ${resultado.ganadas}`);
  console.log(`Perdidas: ${resultado.perdidas}`);
  console.log(`Balance final: ${resultado.balance.toFixed(2)} USDT`);
}

ejecutarSimulacion();
