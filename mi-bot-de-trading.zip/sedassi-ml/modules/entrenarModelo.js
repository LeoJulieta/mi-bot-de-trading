// modules/entrenarModelo.js
const tf = require('@tensorflow/tfjs');
const fs = require('fs');

async function entrenarModelo(datos, campoEntrada, campoSalida, rutaGuardado) {
    // Filtrar y convertir a tensores
    const entradas = datos.map(d => d[campoEntrada]);
    const salidas = datos.map(d => d[campoSalida]);

    const xs = tf.tensor2d(entradas, [entradas.length, 1]);
    const ys = tf.tensor2d(salidas, [salidas.length, 1]);

    // Definir el modelo
    const modelo = tf.sequential();
    modelo.add(tf.layers.dense({ units: 1, inputShape: [1] }));

    modelo.compile({ loss: 'meanSquaredError', optimizer: 'sgd' });

    // Entrenamiento
    await modelo.fit(xs, ys, {
        epochs: 100,
        verbose: 1
    });

    // Guardar modelo
    await modelo.save(`file://${rutaGuardado}`);
    console.log(`Modelo guardado en ${rutaGuardado}`);
}

module.exports = { entrenarModelo };
