const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');
const https = require('https');
const prepararDatos = require('./preparar_datos');
const entrenarModelo = require('./entrenarModelo');

const simbolo = 'USDTBRL';
const intervalo = '1m';
const limite = 1440;
const archivoCandles = path.join(__dirname, '../../candles.json');

// Función para descargar velas si no existe el archivo
function descargarVelasSiEsNecesario() {
  return new Promise((resolve, reject) => {
    if (fs.existsSync(archivoCandles)) {
      console.log('[SEDASSI] Archivo candles.json encontrado.');
      return resolve();
    }

    const url = `https://api.binance.com/api/v3/klines?symbol=${simbolo}&interval=${intervalo}&limit=${limite}`;
    console.log('[SEDASSI] Descargando velas desde Binance...');

    https.get(url, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        const json = JSON.parse(data).map(candle => ({
          timestamp: candle[0],
          open: parseFloat(candle[1]),
          high: parseFloat(candle[2]),
          low: parseFloat(candle[3]),
          close: parseFloat(candle[4]),
          volume: parseFloat(candle[5])
        }));
        fs.writeFileSync(archivoCandles, JSON.stringify(json, null, 2));
        console.log('[SEDASSI] Velas guardadas en candles.json');
        resolve();
      });
    }).on('error', reject);
  });
}

async function flujoPrincipal() {
  try {
    await descargarVelasSiEsNecesario();

    console.log('[SEDASSI] Ejecutando análisis de patrones...');
    execSync('node detectar_patrones.cjs', { stdio: 'inherit' });

    console.log('[SEDASSI] Preparando datos para entrenamiento...');
    const dataset = await prepararDatos('candles.json');

    console.log('[SEDASSI] Entrenando modelo...');
    await entrenarModelo(dataset);

    console.log('[SEDASSI] Entrenamiento finalizado y modelo guardado.');
  } catch (error) {
    console.error('[SEDASSI] Error en flujo principal:', error.message);
  }
}

flujoPrincipal();
