// modules/cargarDatos.js
const fs = require('fs');
const Papa = require('papaparse');

function cargarDatosCSV(ruta) {
    const archivo = fs.readFileSync(ruta, 'utf8');

    return new Promise((resolve, reject) => {
        Papa.parse(archivo, {
            header: true,
            dynamicTyping: true,
            complete: (result) => resolve(result.data),
            error: (err) => reject(err)
        });
    });
}

module.exports = { cargarDatosCSV };
