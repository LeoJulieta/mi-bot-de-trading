const fs = require('fs');

const archivoEntrada = 'dataset_entrenamiento.json';
const archivoSalida = 'dataset_entrenamiento_limpio.json';

const esNumeroValido = (valor) => {
  return (
    typeof valor === 'number' ||
    (typeof valor === 'string' && valor.trim() !== '' && !isNaN(parseFloat(valor)))
  );
};

const convertirANumero = (valor) => {
  return typeof valor === 'number' ? valor : parseFloat(valor);
};

console.log('[SEDASSI] Leyendo dataset...');

const datos = JSON.parse(fs.readFileSync(archivoEntrada, 'utf8'));

const datosLimpios = datos.filter((ejemplo, i) => {
  if (!ejemplo.input || !ejemplo.output) {
    console.log(`[AVISO] Entrada sin input/output en índice ${i}`);
    return false;
  }

  const inputLimpio = ejemplo.input.filter(
    (val) => val !== null && val !== undefined && val !== '' && esNumeroValido(val)
  );
  const outputLimpio = ejemplo.output.filter(
    (val) => val !== null && val !== undefined && val !== '' && esNumeroValido(val)
  );

  if (
    inputLimpio.length !== ejemplo.input.length ||
    outputLimpio.length !== ejemplo.output.length
  ) {
    console.log(`[AVISO] Valores inválidos en índice ${i}, será descartado.`);
    return false;
  }

  if (outputLimpio.length !== 1) {
    console.log(`[AVISO] Output inválido en índice ${i}`);
    return false;
  }

  // Conversiones
  ejemplo.input = inputLimpio.map(convertirANumero);
  ejemplo.output[0] = convertirANumero(outputLimpio[0]);

  return true;
});

console.log(`[SEDASSI] Ejemplos válidos después de depuración: ${datosLimpios.length}`);
fs.writeFileSync(archivoSalida, JSON.stringify(datosLimpios, null, 2));
console.log(`[SEDASSI] Dataset limpio guardado en ${archivoSalida}`);
