const fs = require('fs');

// Parámetros iniciales
let saldo = 300;
let montoBase = 5;
let montoOperacion = montoBase;
let exitoAnterior = true; // Para saber si hay que aplicar Martingala
let historialOperaciones = [];

// Cargar velas de archivo
const velas = JSON.parse(fs.readFileSync('./datos/velas-2025-04-16.json', 'utf8'));

// Detección del patrón (4 interrupciones, luego una vela contraria)
function detectarEntradas(velas) {
  const entradas = [];
  let tendencia = null;
  let interrupciones = 0;

  for (let i = 1; i < velas.length; i++) {
    const anterior = velas[i - 1];
    const actual = velas[i];

    const esVerde = actual.close > actual.open;
    const esRoja = actual.close < actual.open;

    if (!tendencia) {
      if (esVerde) tendencia = 'ALZA';
      else if (esRoja) tendencia = 'BAJA';
      continue;
    }

    const contraria =
      (tendencia === 'ALZA' && esRoja) ||
      (tendencia === 'BAJA' && esVerde);

    if (contraria) {
      interrupciones++;
    } else {
      if (interrupciones >= 4) {
        // Confirmamos entrada en la siguiente vela
        if (i + 1 < velas.length) {
          entradas.push({
            indice: i + 1,
            fecha: new Date(velas[i + 1].openTime).toLocaleString(),
            tipo: tendencia === 'ALZA' ? 'BAJA' : 'ALZA',
            precioEntrada: actual.close
          });
        }
      }
      interrupciones = 0;
      tendencia = esVerde ? 'ALZA' : 'BAJA';
    }
  }

  return entradas;
}

const entradas = detectarEntradas(velas);

// Simular operaciones basadas en el movimiento real de las velas
entradas.forEach((entrada, i) => {
  const siguienteVela = velas[entrada.indice]; // La vela siguiente a la entrada
  const exito = (entrada.tipo === 'BAJA' && siguienteVela.close < entrada.precioEntrada) ||
                (entrada.tipo === 'ALZA' && siguienteVela.close > entrada.precioEntrada);

  const ganancia = exito ? montoOperacion * 0.8 : -montoOperacion;

  saldo += ganancia;

  historialOperaciones.push({
    n: i + 1,
    tipo: entrada.tipo,
    fecha: entrada.fecha,
    monto: montoOperacion,
    exito,
    saldo: saldo.toFixed(2),
    precioEntrada: entrada.precioEntrada,
    precioSalida: siguienteVela.close,
  });

  // Lógica Martingala
  if (!exito) {
    montoOperacion *= 2;
  } else {
    montoOperacion = montoBase;
  }
});

// Mostrar resultados
console.log(`Total de operaciones: ${historialOperaciones.length}`);
console.log(`Saldo final: ${saldo.toFixed(2)} USDT\n`);
historialOperaciones.forEach(op => {
  console.log(`#${op.n}: ${op.tipo} en ${op.fecha} | ${op.exito ? 'Ganó' : 'Perdió'} | Entrada: ${op.precioEntrada} | Salida: ${op.precioSalida} | Saldo: ${op.saldo}`);
});
