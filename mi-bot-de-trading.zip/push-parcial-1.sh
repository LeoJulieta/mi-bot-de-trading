#!/data/data/com.termux/files/usr/bin/bash

# Push parcial 1
git add README.md estructura_proyecto.txt Sclean.sh evaluadorEfectividad.js actualizarVelas.js evaluar_resultado_de_patrones.js actualizar_historico.js fetchCandles.js analizarConMartingala.js generar_dataset_csv.js
git commit -m "Push parcial 1"
git push origin main
