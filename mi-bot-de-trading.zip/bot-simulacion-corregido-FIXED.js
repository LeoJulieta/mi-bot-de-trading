// bot-simulacion.js

const fs = require('fs');
const fetch = require('node-fetch');
const readline = require('readline');
const path = require('path');

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

const carpetaResultados = 'resultadosBotF';
if (!fs.existsSync(carpetaResultados)) fs.mkdirSync(carpetaResultados);

function preguntar(pregunta) {
  return new Promise(resolve => rl.question(pregunta, resp => resolve(resp)));
}

async function obtenerVelas(fecha) {
  const startTime = new Date(`${fecha}T00:00:00Z`).getTime();
  const endTime = startTime + 24 * 60 * 60 * 1000;
  const limit = 1440;

  const url = `https://api.binance.com/api/v3/klines?symbol=USDTBRL&interval=1m&startTime=${startTime}&endTime=${endTime}&limit=${limit}`;
  const res = await fetch(url);
  const data = await res.json();

  return data.map(v => ({
    openTime: v[0],
    open: parseFloat(v[1]),
    high: parseFloat(v[2]),
    low: parseFloat(v[3]),
    close: parseFloat(v[4]),
    volume: parseFloat(v[5])
  }));
}

function simularOperacion(patron, monto) {
  const exito = Math.random() < 0.6; // 60% de aciertos
  const ganancia = exito ? monto * 0.8 : -monto;
  return { exito, ganancia };
}

function guardarArchivo(fecha, operaciones, total, saldoFinal, aciertos, capitalInicial) {
  const nombreBase = `${fecha.replace(/\//g, '-')}`;
  const resumen = `Fecha: ${fecha}\nOperaciones: ${operaciones.length}\nAciertos: ${aciertos} (${((aciertos / operaciones.length) * 100).toFixed(2)}%)\nSaldo Inicial: ${capitalInicial.toFixed(2)} USDT\nSaldo Final: ${saldoFinal.toFixed(2)} USDT\nGanancia Neta: ${(saldoFinal - capitalInicial).toFixed(2)} USDT\n`;

  const log = operaciones.map(op => `${op.hora} | ${op.patron} | ${op.resultado} | ${op.ganancia.toFixed(2)} USDT | Saldo: ${op.saldo.toFixed(2)}`).join('\n');

  fs.writeFileSync(`${carpetaResultados}/${nombreBase}.log`, resumen + '\n' + log);
  fs.writeFileSync(`${carpetaResultados}/${nombreBase}.json`, JSON.stringify(operaciones, null, 2));

  const csv = 'Hora,Patron,Resultado,Ganancia,Saldo\n' + operaciones.map(op => `${op.hora},${op.patron},${op.resultado},${op.ganancia.toFixed(2)},${op.saldo.toFixed(2)}`).join('\n');
  fs.writeFileSync(`${carpetaResultados}/${nombreBase}.csv`, csv);

  console.log('\nResumen del día:');
  console.log(resumen);
  console.table(operaciones.map(op => ({
    Hora: op.hora,
    Patrón: op.patron,
    Resultado: op.resultado,
    Ganancia: op.ganancia.toFixed(2),
    Saldo: op.saldo.toFixed(2)
  })));
}

async function ejecutarBacktest(fecha, capitalInicial, montoOperacion) {
  const velas = await obtenerVelas(fecha);
  let saldo = capitalInicial;
  const operaciones = [];
  let aciertos = 0;

  
  for (let i = 0; i < velas.length; i++) {
    if (saldo < montoOperacion) {
      console.log(`
Te quedaste sin saldo el ${fecha} a las ${new Date(velas[i].openTime).toLocaleTimeString('es-AR')}`);
      break;
    }

    saldo -= montoOperacion;
    const patron = `Patrón_${Math.ceil(Math.random() * 5)}`;
    const { exito, ganancia } = simularOperacion(patron, montoOperacion);

    if (exito) {
      saldo += montoOperacion + ganancia;
    }

    operaciones.push({
      hora: new Date(velas[i].openTime).toLocaleTimeString('es-AR'),
      patron,
      resultado: exito ? 'GANÓ' : 'PERDIÓ',
      ganancia: exito ? ganancia : -montoOperacion,
      saldo
    });

    if (exito) aciertos++;
  }


  guardarArchivo(fecha, operaciones, operaciones.length, saldo, aciertos, capitalInicial);
}

async function main() {
  const modo = await preguntar('¿Querés hacer backtest de 1 día o de un rango? (1/rango): ');
  const capital = parseFloat(await preguntar('Capital total disponible (USDT): '));
  const monto = parseFloat(await preguntar('Monto por operación (USDT): '));

  if (modo === '1') {
    const fecha = await preguntar('Ingresá la fecha (YYYY-MM-DD): ');
    await ejecutarBacktest(fecha, capital, monto);
    rl.close();
  } else {
    const desde = await preguntar('Desde (YYYY-MM-DD): ');
    const hasta = await preguntar('Hasta (YYYY-MM-DD): ');

    let fechaActual = new Date(desde);
    const fechaFinal = new Date(hasta);

    while (fechaActual <= fechaFinal) {
      const f = fechaActual.toISOString().split('T')[0];
      console.log(`\nProcesando ${f}...`);
      await ejecutarBacktest(f, capital, monto);
      fechaActual.setDate(fechaActual.getDate() + 1);
    }
    rl.close();
  }
}

main();
