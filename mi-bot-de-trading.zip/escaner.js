// escaner.js
const fs = require("fs");
const path = require("path");

function listarArchivos(dir, archivos = []) {
  fs.readdirSync(dir).forEach(file => {
    const ruta = path.join(dir, file);
    if (fs.statSync(ruta).isDirectory()) {
      listarArchivos(ruta, archivos);
    } else {
      archivos.push(ruta);
    }
  });
  return archivos;
}

const archivos = listarArchivos("./");
console.log("Archivos encontrados:\n", archivos.join("\n"));
