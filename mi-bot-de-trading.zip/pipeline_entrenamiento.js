const tf = require('@tensorflow/tfjs');
const fs = require('fs');

// Rutas
const RUTA_DATASET = 'dataset_entrenamiento.json';
const RUTA_MODELO = 'modelo_entrenado';

console.log('[SEDASSI] Cargando datos de entrenamiento...');

let datos;
try {
  datos = JSON.parse(fs.readFileSync(RUTA_DATASET, 'utf8'));
} catch (err) {
  console.error('[SEDASSI] Error al leer el dataset:', err.message);
  process.exit(1);
}

if (!Array.isArray(datos) || datos.length === 0) {
  console.error('[SEDASSI] El dataset está vacío o malformado.');
  process.exit(1);
}

const datosX = datos.map(d => d.input);
const datosY = datos.map(d => [d.salida]);

if (!Array.isArray(datosX[0]) || datosX[0].length === 0) {
  console.error('[SEDASSI] Los datos de entrada están vacíos o mal estructurados.');
  process.exit(1);
}

// Validación avanzada de datos
for (let i = 0; i < datosX.length; i++) {
  const entrada = datosX[i];
  const salida = datosY[i];

  if (!Array.isArray(entrada) || entrada.length === 0) {
    console.error(`[SEDASSI] Entrada malformada en índice ${i}`);
    process.exit(1);
  }

  for (let j = 0; j < entrada.length; j++) {
    const valor = entrada[j];
    if (typeof valor !== 'number' || isNaN(valor) || !isFinite(valor)) {
      console.error(`[SEDASSI] Valor inválido detectado en input[${i}][${j}]:`, valor);
      process.exit(1);
    }
  }

  if (!Array.isArray(salida) || salida.length !== 1 || (salida[0] !== 0 && salida[0] !== 1)) {
    console.error(`[SEDASSI] Valor de salida inválido en índice ${i}:`, salida);
    process.exit(1);
  }
}

// Crear tensores
const xs = tf.tensor2d(datosX, [datosX.length, datosX[0].length]);
const ys = tf.tensor2d(datosY, [datosY.length, 1]);

// Definir modelo
const model = tf.sequential();
model.add(tf.layers.dense({ units: 8, activation: 'relu', inputShape: [xs.shape[1]] }));
model.add(tf.layers.dense({ units: 4, activation: 'relu' }));
model.add(tf.layers.dense({ units: 1, activation: 'sigmoid' }));

model.compile({
  optimizer: tf.train.adam(),
  loss: tf.losses.logLoss,
  metrics: ['accuracy']
});

// Entrenamiento
console.log(`[SEDASSI] Entrenando modelo con ${datos.length} ejemplos...`);
(async () => {
  await model.fit(xs, ys, {
    epochs: 20,
    shuffle: true,
    callbacks: {
      onEpochEnd: (epoch, logs) => {
        console.log(`[Época ${epoch + 1}] pérdida: ${logs.loss.toFixed(4)} - accuracy: ${logs.acc.toFixed(4)}`);
      }
    }
  });

  // Guardar modelo
  console.log('[SEDASSI] Guardando modelo entrenado...');
  await model.save(tf.io.withSaveHandler(async (modelArtifacts) => {
    if (!fs.existsSync(RUTA_MODELO)) fs.mkdirSync(RUTA_MODELO);

    fs.writeFileSync(`${RUTA_MODELO}/model.json`, JSON.stringify({
      modelTopology: modelArtifacts.modelTopology,
      weightsManifest: [{
        paths: ['weights.bin'],
        weights: modelArtifacts.weightSpecs
      }]
    }));

    fs.writeFileSync(`${RUTA_MODELO}/weights.bin`, Buffer.from(modelArtifacts.weightData));

    console.log('[SEDASSI] Entrenamiento completado y modelo guardado.');
  }));
})();
