// telegram_bot.js
const TelegramBot = require('node-telegram-bot-api');
const fs = require('fs');
const { exec } = require('child_process');

const token = '8027810765:AAFY-Tn0UgXNpOocaeESIv4fwFdaSu3a9ZE';
const bot = new TelegramBot(token, { polling: true });

const USUARIO_AUTORIZADO = 123456789; // ← reemplazar con tu ID real de Telegram

bot.on('message', (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  if (userId !== USUARIO_AUTORIZADO) {
    return bot.sendMessage(chatId, 'Acceso denegado.');
  }

  const texto = msg.text;

  if (texto === '/start') {
    return bot.sendMessage(chatId, '¡Bot de Sedassi conectado y listo!');
  }

  if (texto === '/estado') {
    return bot.sendMessage(chatId, 'Todo funcionando. ¿Qué querés hacer?');
  }

  if (texto === '/ver_modelo') {
    const modeloPath = './modelo_entrenado/model.json';
    if (fs.existsSync(modeloPath)) {
      return bot.sendDocument(chatId, modeloPath);
    } else {
      return bot.sendMessage(chatId, 'No se encontró el modelo entrenado.');
    }
  }

  if (texto.startsWith('/ejecutar ')) {
    const comando = texto.replace('/ejecutar ', '');
    bot.sendMessage(chatId, `Ejecutando: ${comando}`);
    exec(comando, (error, stdout, stderr) => {
      if (error) return bot.sendMessage(chatId, `Error: ${error.message}`);
      if (stderr) return bot.sendMessage(chatId, `Stderr: ${stderr}`);
      return bot.sendMessage(chatId, `Resultado:\n${stdout}`);
    });
  }
});
