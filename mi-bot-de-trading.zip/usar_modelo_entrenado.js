const tf = require('@tensorflow/tfjs'); // usar tfjs-node si lo tenés
const path = 'file://./modelo_entrenado';

(async () => {
  console.log('[SEDASSI] Cargando modelo entrenado...');
  const modelo = await tf.loadLayersModel(path + '/model.json');
  console.log('[SEDASSI] Modelo cargado exitosamente.');

  // Ejemplo de predicción con una muestra de entrada ficticia
  const muestra = tf.tensor2d([
    [5.88, 5.89, 5.87, 5.88, 3245.6, 1] // open, high, low, close, volume, direccion(1=alcista, 0=bajista)
  ]);

  const prediccion = modelo.predict(muestra);
  const resultado = await prediccion.array();

  console.log('[SEDASSI] Predicción:', resultado);
})();
