// convertir_resultados.js
const fs = require('fs');

const rutaEntrada = './resultados_evaluados.json';
const rutaSalida = './resultados_convertidos.json';

try {
  const datos = JSON.parse(fs.readFileSync(rutaEntrada, 'utf8'));

  const convertidos = datos
    .filter(p => p.resultado === 'ganador' || p.resultado === 'perdedor')
    .map(p => ({
      ...p,
      resultado: p.resultado === 'ganador' ? 1 : 0
    }));

  fs.writeFileSync(rutaSalida, JSON.stringify(convertidos, null, 2));
  console.log(`[SEDASSI] Resultados convertidos guardados en ${rutaSalida}`);
} catch (error) {
  console.error('[SEDASSI] Error al convertir resultados:', error);
}
