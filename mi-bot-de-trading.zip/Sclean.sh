#!/data/data/com.termux/files/usr/bin/bash

echo "Iniciando limpieza con respeto, sabiduría y fuerza..."

# Limpia caché de npm
echo "Limpiando cache de NPM..."
npm cache clean --force

# Limpia logs de PM2
echo "Limpiando logs de PM2..."
pm2 flush

# Limpia paquetes node_modules (opcionales si ya están en package.json)
echo "¿Querés borrar node_modules? (s/n)"
read BORRAR_NM
if [ "$BORRAR_NM" = "s" ]; then
  find ~ -type d -name "node_modules" -exec rm -rf {} +
  echo "Node_modules eliminados."
fi

# Elimina backups antiguos si existen (opcional)
echo "¿Querés mover tus backups de 'mi-bot-de-trading/backups' a otra carpeta? (s/n)"
read MOVER_BACKUPS
if [ "$MOVER_BACKUPS" = "s" ]; then
  mkdir -p ~/backups_externos
  mv ~/mi-bot-de-trading/backups/* ~/backups_externos/
  echo "Backups movidos a ~/backups_externos/"
fi

# Elimina archivos git que ya no se usan (compacta git)
echo "Limpiando y compactando Git..."
cd ~/mi-bot-de-trading
git gc --aggressive --prune=now

echo "Limpieza completada. Termux agradece tu sabiduría, Sensei."
