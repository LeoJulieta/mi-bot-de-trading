const fs = require('fs');

const RUTA_ORIGINAL = 'dataset_entrenamiento.json';
const RUTA_DEPURADO = 'dataset_entrenamiento_limpio.json';

console.log('[SEDASSI] Leyendo dataset original...');

let datos;
try {
  datos = JSON.parse(fs.readFileSync(RUTA_ORIGINAL, 'utf8'));
} catch (err) {
  console.error('[SEDASSI] Error al leer el dataset original:', err.message);
  process.exit(1);
}

if (!Array.isArray(datos)) {
  console.error('[SEDASSI] El dataset no es un array.');
  process.exit(1);
}

console.log(`[SEDASSI] Total de ejemplos originales: ${datos.length}`);

const datosValidos = datos.filter((d, i) => {
  if (
    !d ||
    !Array.isArray(d.input) ||
    d.input.some(v => typeof v !== 'number' || !isFinite(v)) ||
    (d.salida !== 0 && d.salida !== 1)
  ) {
    console.warn(`[AVISO] Entrada inválida en índice ${i}, será descartada.`);
    return false;
  }
  return true;
});

console.log(`[SEDASSI] Ejemplos válidos después de depuración: ${datosValidos.length}`);

fs.writeFileSync(RUTA_DEPURADO, JSON.stringify(datosValidos, null, 2));
console.log(`[SEDASSI] Dataset depurado guardado en ${RUTA_DEPURADO}`);
