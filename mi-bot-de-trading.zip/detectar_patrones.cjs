// detectar_patrones.cjs

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');
const chalk = require('chalk');

// Modo: 'realtime' o 'historico'
const modo = 'realtime';

function cargarVelasHistoricas() {
  const archivos = fs.readdirSync('datos').filter(f => f.endsWith('.json'));
  let todas = [];
  for (const archivo of archivos) {
    const data = JSON.parse(fs.readFileSync(path.join('datos', archivo)));
    todas = todas.concat(data);
  }
  return todas;
}

function cargarVelasRealtime() {
  return JSON.parse(fs.readFileSync('candles.json'));
}

// Cargar módulos de patrones
const detectar4Cortes = require('./modules/patrones/patron_4cortes_reversa');
const detectarEngulfing = require('./modules/patrones/patron_engulfing');
const detectarHammerHanging = require('./modules/patrones/patron_hammer_hangingman');
const detectarDoji = require('./modules/patrones/patron_doji');
const detectarMorningEvening = require('./modules/patrones/patron_morning_evening_star');
const detectarPiercingDarkCloud = require('./modules/patrones/patron_piercing_darkcloud');
const detectarThreeSoldiersCrows = require('./modules/patrones/patron_three_soldiers_crows');
const detectarHarami = require('./modules/patrones/patron_harami');
const detectarTweezer = require('./modules/patrones/patron_tweezer');
const detectarBreakout = require('./modules/patrones/patron_breakout_consolidacion');

let datos = [];

if (modo === 'historico') {
  console.log(chalk.cyan('[SEDASSI] Modo: Histórico'));
  datos = cargarVelasHistoricas();
} else {
  console.log(chalk.cyan('[SEDASSI] Modo: Tiempo real'));

  const archivoRealtime = 'candles.json';
  if (!fs.existsSync(archivoRealtime)) {
    console.log(chalk.yellow('[SEDASSI] candles.json no encontrado. Descargando datos desde Binance...'));
    try {
      execSync('node modules/obtener_datos_reales.js', { stdio: 'inherit' });
    } catch (err) {
      console.error(chalk.red('[SEDASSI] Error al ejecutar obtener_datos_reales.js:'), err.message);
      process.exit(1);
    }
  }

  datos = cargarVelasRealtime();
}

// Detectar patrones
const resultados = [
  ...detectar4Cortes(datos),
  ...detectarEngulfing(datos),
  ...detectarHammerHanging(datos),
  ...detectarDoji(datos),
  ...detectarMorningEvening(datos),
  ...detectarPiercingDarkCloud(datos),
  ...detectarThreeSoldiersCrows(datos),
  ...detectarHarami(datos),
  ...detectarTweezer(datos),
  ...detectarBreakout(datos),
];

// Guardar resultados
fs.writeFileSync('resultados_patrones.json', JSON.stringify(resultados, null, 2));
console.log(chalk.green('[SEDASSI] Detección completada. Resultados guardados en resultados_patrones.json.'));
