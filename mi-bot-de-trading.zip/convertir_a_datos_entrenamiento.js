const fs = require('fs');

const RUTA_ENTRADA = 'resultados_evaluados.json';
const RUTA_SALIDA = 'dataset_entrenamiento.json';

console.log('[SEDASSI] [6/8] Convirtiendo datos evaluados para entrenamiento...');

if (!fs.existsSync(RUTA_ENTRADA)) {
  console.error('[SEDASSI] Archivo de resultados no encontrado:', RUTA_ENTRADA);
  process.exit(1);
}

const datos = JSON.parse(fs.readFileSync(RUTA_ENTRADA));
const patronesUnicos = [...new Set(datos.map(p => p.tipo))];
const dataset = [];

datos.forEach(patron => {
  if (!patron.vela || patron.resultado === undefined) return;

  // Normalización simple
  const { open, high, low, close, volume } = patron.vela;
  const rango = high - low || 1; // evitar división por cero
  const velaNormalizada = [
    (open - low) / rango,
    (high - low) / rango,
    (close - low) / rango,
    volume / 1000 // ajuste simple
  ];

  // One-hot del tipo de patrón
  const oneHotTipo = patronesUnicos.map(tipo => tipo === patron.tipo ? 1 : 0);

  // Dirección: 1 (alcista), -1 (bajista)
  const direccionCodificada = patron.direccion === 'alcista' ? 1 : -1;

  const entrada = [...velaNormalizada, direccionCodificada, ...oneHotTipo];
  const salida = [patron.resultado ? 1 : 0];

  dataset.push({ input: entrada, output: salida });
});

fs.writeFileSync(RUTA_SALIDA, JSON.stringify(dataset, null, 2));
console.log(`[SEDASSI] Datos convertidos y guardados en ${RUTA_SALIDA}`);
