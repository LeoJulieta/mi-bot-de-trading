require("dotenv").config();
const notificar = require("./telegram/notificar");
const { Telegraf } = require("telegraf");
const express = require("express");
const cors = require("cors");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = 3000;

// Configurar bot
const bot = new Telegraf(process.env.BOT_TOKEN);

// Middleware Express
app.use(cors());

// Función para leer archivos JSON
function leerArchivoJSON(nombreArchivo) {
  const ruta = path.join(__dirname, nombreArchivo);
  const contenido = fs.readFileSync(ruta, "utf-8");
  return JSON.parse(contenido);
}

// Endpoints
app.get("/api/candles", (req, res) => {
  try {
    const datos = leerArchivoJSON("candles.json");
    res.json(datos);
  } catch (err) {
    console.error("Error al leer candles.json:", err);
    res.status(500).send("Error al leer candles.json");
  }
});

app.get("/api/backtest", (req, res) => {
  try {
    const datos = leerArchivoJSON("backtest.json");
    res.json(datos);
  } catch (err) {
    console.error("Error al leer backtest.json:", err);
    res.status(500).send("Error al leer backtest.json");
  }
});

// Telegram - Comando /start
bot.start((ctx) => {
  ctx.reply(`Hola ${ctx.from.first_name}, el bot está listo para ayudarte.`);
});

bot.on("text", (ctx) => {
  const mensaje = ctx.message.text.toLowerCase();

  if (mensaje.includes("hola")) {
    ctx.reply("¡Hola! ¿Cómo estás?");
  } else if (mensaje === "/status") {
    ctx.reply("El bot está funcionando correctamente.");
  } else {
    ctx.reply(`Recibido: "${mensaje}"`);
  }
});

// Telegram - Respuesta a cualquier texto
bot.on("text", (ctx) => {
  const mensaje = ctx.message.text.toLowerCase();

  if (mensaje.includes("hola")) {
    ctx.reply("Hola! ¿En qué te puedo ayudar?");
  } else if (mensaje === "/status") {
    ctx.reply("El bot está funcionando correctamente.");
  } else {
    ctx.reply(`Mensaje recibido: ${mensaje}`);
  }
});

// Iniciar bot y servidor
bot.launch();
console.log("Bot de Telegram iniciado");

app.listen(PORT, () => {
  console.log(`Servidor escuchando en http://localhost:${PORT}`);
notificar("Bot iniciado correctamente en " + new Date().toLocaleString());
});
