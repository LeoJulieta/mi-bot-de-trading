// descargar_por_fecha.js
const fs = require('fs');
const path = require('path');
const axios = require('axios');

const carpeta = 'datos';
const simbolo = 'USDTBRL';
const intervalo = '1m';

function formatearFecha(fecha) {
  const y = fecha.getFullYear();
  const m = String(fecha.getMonth() + 1).padStart(2, '0');
  const d = String(fecha.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

async function descargarVelasPorFecha(fechaString) {
  const archivo = path.join(carpeta, `velas-${fechaString}.json`);
  if (fs.existsSync(archivo)) {
    console.log(`Ya existe: ${archivo}`);
    return;
  }

  const [y, m, d] = fechaString.split('-');
  const start = new Date(`${fechaString}T00:00:00Z`).getTime();
  const end = new Date(`${fechaString}T23:59:00Z`).getTime();

  const url = `https://api.binance.com/api/v3/klines?symbol=${simbolo}&interval=${intervalo}&startTime=${start}&endTime=${end}&limit=1440`;

  try {
    const { data } = await axios.get(url);
    fs.writeFileSync(archivo, JSON.stringify(data, null, 2));
    console.log(`Descargado y guardado: ${archivo}`);
  } catch (error) {
    console.error(`Error descargando ${fechaString}:`, error.message);
  }
}

// Leer fecha desde argumento
const fechaArg = process.argv[2];
if (!fechaArg) {
  console.log('Usá: node descargar_por_fecha.js YYYY-MM-DD');
  process.exit(1);
}

descargarVelasPorFecha(fechaArg);
