// Logging de operaciones
console.log('Registrando operación');