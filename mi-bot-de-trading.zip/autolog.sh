#!/data/data/com.termux/files/usr/bin/bash

# Ruta base del proyecto
cd ~/mi-bot-de-trading || { echo "Error al cambiar de directorio"; exit 1; }

# Fecha actual
FECHA=$(date '+%Y-%m-%d')
HORA=$(date '+%H:%M:%S')
TIMESTAMP=$(date '+%Y-%m-%d_%H-%M')

# Ejecutar escaneo de archivos y loguear
echo "[$HORA] Iniciando escaneo automático..." >> logs/autolog.log
node tools/ls-scan.js >> logs/autolog.log 2>&1 || { echo "Error al ejecutar el escaneo." >> logs/autolog.log; ERROR_MSG="❌ Error en escaneo con ls-scan.js"; }

# Guardar fragmento de charla desde notificaciones
if command -v jq > /dev/null; then
    CHARLA=$(timeout 3s termux-notification-list | jq -r '.[] | select(.app=="com.termux") | .summary' | tail -n 1)
    if [ -n "$CHARLA" ]; then
        echo "Log de charla: $(date)" >> chatlog.md
        echo "$CHARLA" >> chatlog.md
        echo "" >> chatlog.md
    else
        echo "No se encontraron nuevas notificaciones de Termux." >> logs/autolog.log
    fi
else
    echo "jq no está instalado. No se pudo guardar la charla." >> logs/autolog.log
fi

# Crear resumen diario
mkdir -p resumenes
RESUMEN="resumenes/$FECHA-resumen.md"
echo "## Resumen del $FECHA" > "$RESUMEN"
echo "- Escaneo automático ejecutado a las $HORA" >> "$RESUMEN"
echo "- Backup de charla y archivos sincronizado" >> "$RESUMEN"
echo "- Cambios subidos a GitHub" >> "$RESUMEN"

# Actualizar README dinámico
echo "# Proyecto: Mi bot de trading" > README.md
echo "" >> README.md
echo "Última actualización: $(date)" >> README.md
echo "" >> README.md
echo "## Estructura de carpetas" >> README.md
tree -L 2 >> README.md
echo "" >> README.md
echo "## Últimos cambios" >> README.md
git log -3 --pretty=format:"- %h %s (%ci)" >> README.md

# Ruta y nombre del archivo de backup
BACKUP_FILE="backups/backup-$(date +%F_%H-%M).zip"
BACKUP_MODE="liviano"  # Cambiar a "completo" si lo necesitás
mkdir -p backups

# Crear el backup según el modo elegido
if [ "$BACKUP_MODE" = "completo" ]; then
    zip -r "$BACKUP_FILE" . > /dev/null
    echo "✅ Backup COMPLETO generado: $BACKUP_FILE" >> logs/autolog.log
else
    zip -r "$BACKUP_FILE" . -x "*.git*" "backups/*" > /dev/null
    echo "✅ Backup LIVIANO generado: $BACKUP_FILE" >> logs/autolog.log
fi
echo "Backup ejecutado en: $(date)" >> logs/autolog.log

# Obtener tamaño del backup
BACKUP_SIZE=$(du -h "$BACKUP_FILE" | cut -f1)

# Git add, commit y push
git add .
git commit -m "Auto backup y sincronización: $FECHA $HORA" >> logs/git.log 2>&1 || ERROR_MSG="❌ Error al hacer commit"
git push origin main >> logs/git.log 2>&1 || ERROR_MSG="❌ Error al hacer push a GitHub"

# Verificar si hay commits en remoto aún no bajados
git fetch origin main > /dev/null 2>&1
COMMITS_ADELANTADOS=$(git log HEAD..origin/main --oneline)

if [ -n "$COMMITS_ADELANTADOS" ]; then
    REMOTO_STATUS="Hay commits NUEVOS en remoto que aún no están sincronizados:"
else
    REMOTO_STATUS="Todo sincronizado con el repositorio remoto."
fi

# Agregar estado remoto al README
echo "" >> README.md
echo "## Estado del repositorio remoto" >> README.md
echo "$REMOTO_STATUS" >> README.md
echo "$COMMITS_ADELANTADOS" >> README.md

# Últimos commits locales
COMMITS=$(git log -3 --pretty=format:"- %h %s (%ci)")

# Webhook final con resumen completo
WEBHOOK_MSG=$(cat <<EOF
${ERROR_MSG:-✅ Autolog finalizado correctamente}

- Fecha: $FECHA
- Hora: $HORA
- Backup generado: $BACKUP_FILE
- Tamaño del backup: $BACKUP_SIZE
- Modo de backup: $BACKUP_MODE

$REMOTO_STATUS
$COMMITS_ADELANTADOS

- Últimos commits locales:
$COMMITS
EOF
)

curl -X POST -H "Content-Type: text/plain" -d "$WEBHOOK_MSG" "https://webhook.site/119a428b-adde-4c9f-95c1-a2d8bd1bf145"
