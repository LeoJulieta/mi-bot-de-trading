const fs = require("fs");
const path = require("path");

const carpetaVelas = "./datos";
const archivoCSV = "./data/datos_historicos.csv";

const archivos = fs.readdirSync(carpetaVelas).filter(nombre => nombre.startsWith("velas-") && nombre.endsWith(".json"));

// Encabezado del CSV con columna de par
let contenidoCSV = "par,fecha,precio_apertura,precio_maximo,precio_minimo,precio_cierre\n";

archivos.forEach(nombreArchivo => {
  const ruta = path.join(carpetaVelas, nombreArchivo);
  const datos = JSON.parse(fs.readFileSync(ruta, "utf8"));

  datos.forEach(vela => {
    if (!vela.timestamp || isNaN(new Date(vela.timestamp))) return;

    const fecha = new Date(vela.timestamp).toISOString().replace("T", " ").substring(0, 16);
    const apertura = vela.open ?? "";
    const maximo = vela.high ?? "";
    const minimo = vela.low ?? "";
    const cierre = vela.close ?? "";
    const par = "USDTBRL"; // fijo por ahora

    contenidoCSV += `${par},${fecha},${apertura},${maximo},${minimo},${cierre}\n`;
  });
});

if (!fs.existsSync("./data")) {
  fs.mkdirSync("./data");
}

fs.writeFileSync(archivoCSV, contenidoCSV, "utf8");

console.log(`CSV generado correctamente con ${archivos.length} archivos de velas para el par USDTBRL.`);
