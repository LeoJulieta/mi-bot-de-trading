// telegram/index.js

const TelegramBot = require('node-telegram-bot-api');
const sedassiBot = require('./sedassibot');

// Token del bot (guardalo seguro)
const token = '8027810765:AAFY-Tn0UgXNpOocaeESIv4fwFdaSu3a9ZE';

// Crear instancia del bot
const bot = new TelegramBot(token, { polling: true });

// ID de tu usuario (Leo)
const ADMIN_ID = 8120496449;

// Escuchar comando /start
bot.onText(/\/start/, (msg) => {
  if (msg.chat.id === ADMIN_ID) {
    bot.sendMessage(msg.chat.id, 'Bienvenido Sensei Leo. El bot está activo.');
    sedassiBot.inicializar(bot, msg.chat.id);
  } else {
    bot.sendMessage(msg.chat.id, 'Acceso denegado.');
  }
});

// Escuchar otros comandos (ejemplo: /estado)
bot.onText(/\/estado/, (msg) => {
  if (msg.chat.id === ADMIN_ID) {
    const estado = sedassiBot.obtenerEstado();
    bot.sendMessage(msg.chat.id, `Estado actual:\n${estado}`);
  }
});

// También podrías escuchar cualquier mensaje si lo necesitás
// bot.on('message', (msg) => {
//   console.log(msg.text);
// });
