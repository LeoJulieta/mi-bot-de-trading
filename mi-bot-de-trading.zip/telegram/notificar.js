require("dotenv").config();
const { Telegraf } = require("telegraf");

const bot = new Telegraf(process.env.BOT_TOKEN);
const chatId = process.env.USER_ID;

function notificar(mensaje) {
  if (!chatId || !process.env.BOT_TOKEN) {
    console.error("No se encontró el chatId o BOT_TOKEN en .env");
    return;
  }

  bot.telegram.sendMessage(chatId, `📢 ${mensaje}`).catch(err => {
    console.error("Error al enviar mensaje de Telegram:", err.message);
  });
}

module.exports = notificar;
