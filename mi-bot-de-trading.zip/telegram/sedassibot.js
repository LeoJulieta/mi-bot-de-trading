// telegram/sedassibot.js
const fs = require('fs');

function estadoBot(msg, bot) {
  const chatId = msg.chat.id;
  let response = '[SEDASSI BOT]\nEstado actual:\n';

  // Verificamos si existen ciertos archivos para saber el estado
  const checks = [
    { archivo: 'resultados_convertidos.json', descripcion: 'Resultados convertidos' },
    { archivo: 'dataset_entrenamiento.json', descripcion: 'Dataset de entrenamiento' },
    { archivo: 'modelo_entrenado/model.json', descripcion: 'Modelo entrenado' },
    { archivo: 'predicciones.json', descripcion: 'Predicciones recientes' }
  ];

  checks.forEach(c => {
    response += `- ${c.descripcion}: ${fs.existsSync(c.archivo) ? '✅' : '❌'}\n`;
  });

  bot.sendMessage(chatId, response);
}

module.exports = {
  estadoBot
};
