const fs = require('fs');
const path = require('path');
const axios = require('axios');
const readline = require('readline');

// === CONFIGURACIÓN ===
const carpetaDatos = 'datos';
const simbolo = 'USDTBRL';
const intervalo = '1m';

// === FUNCIONES ===
function obtenerFechasAnteriores(fechaStr) {
  const fecha = new Date(fechaStr);
  const fechas = [];
  for (let i = 7; i <= 14; i++) {
    const temp = new Date(fecha);
    temp.setDate(temp.getDate() - (fecha.getDate() - i));
    fechas.push(temp.toISOString().split('T')[0]);
  }
  return fechas;
}

function archivoExisteParaFecha(fechaStr) {
  return fs.existsSync(path.join(carpetaDatos, `velas-${fechaStr}.json`));
}

async function descargarVelas(fechaStr) {
  const archivo = path.join(carpetaDatos, `velas-${fechaStr}.json`);
  const start = new Date(`${fechaStr}T00:00:00Z`).getTime();
  const end = new Date(`${fechaStr}T23:59:00Z`).getTime();

  const url = `https://api.binance.com/api/v3/klines?symbol=${simbolo}&interval=${intervalo}&startTime=${start}&endTime=${end}&limit=1440`;

  try {
    const { data } = await axios.get(url);
    fs.writeFileSync(archivo, JSON.stringify(data, null, 2));
    console.log(`Descargado: ${fechaStr}`);
  } catch (error) {
    console.error(`Error al descargar ${fechaStr}:`, error.message);
  }
}

function entrenarConDatos(fechas) {
  fechas.forEach(fecha => {
    const archivo = path.join(carpetaDatos, `velas-${fecha}.json`);
    if (fs.existsSync(archivo)) {
      console.log(`Entrenando con: ${fecha}`);
      // Acá iría tu lógica de entrenamiento real
    }
  });
  console.log("Modelo entrenado.");
}

function hacerBacktest(fechaStr) {
  const archivo = path.join(carpetaDatos, `velas-${fechaStr}.json`);
  if (!fs.existsSync(archivo)) {
    console.error(`No se encuentra el archivo para ${fechaStr}`);
    return;
  }

  console.log(`\n=== BACKTEST para ${fechaStr} ===`);
  // Acá va tu lógica de backtest real
}

// === ENTRADA DESDE CONSOLA ===
async function obtenerFechaObjetivo() {
  const argFecha = process.argv[2];
  if (argFecha) return argFecha;

  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
  });

  return new Promise(resolve => {
    rl.question('Ingrese una fecha (YYYY-MM-DD): ', (respuesta) => {
      rl.close();
      resolve(respuesta);
    });
  });
}

// === EJECUCIÓN PRINCIPAL ===
(async () => {
  const fechaObjetivo = await obtenerFechaObjetivo();
  const fechas = obtenerFechasAnteriores(fechaObjetivo);

  console.log("\n=== Verificando y descargando datos ===");
  for (const fecha of fechas.concat([fechaObjetivo])) {
    if (!archivoExisteParaFecha(fecha)) {
      await descargarVelas(fecha);
    } else {
      console.log(`Ya existe: ${fecha}`);
    }
  }

  console.log("\n=== Entrenando modelo ===");
  entrenarConDatos(fechas);

  console.log("\n=== Ejecutando backtest ===");
  hacerBacktest(fechaObjetivo);
})();
