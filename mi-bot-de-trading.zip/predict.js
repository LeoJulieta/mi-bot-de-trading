import * as tf from '@tensorflow/tfjs';
import fs from 'fs';

// Función asincrónica principal
const main = async () => {
  // Cargar el modelo entrenado (cambiá la ruta a tu modelo real)
  const model = await tf.loadLayersModel('file://./modelo/model.json');

  // Leer las velas existentes
  const archivo = './datos/velas.json';
  const velas = JSON.parse(fs.readFileSync(archivo, 'utf8'));

  const obtenerDatosParaEntrenamiento = (velas) => {
    return velas.map(vela => [
      vela.open,
      vela.high,
      vela.low,
      vela.close,
      vela.volume
    ]);
  };

  const normalizarDatos = (datos) => {
    // Ajustá esta función si usaste normalización en el entrenamiento
    return datos;
  };

  const datos = obtenerDatosParaEntrenamiento(velas);
  const ultimaVela = datos[datos.length - 1];
  const velaAnterior = datos[datos.length - 2];

  const datosEntrada = normalizarDatos([velaAnterior, ultimaVela]);

  // Realizar la predicción
  const inputTensor = tf.tensor([datosEntrada]);
  const prediccion = model.predict(inputTensor);

  const predicciones = await prediccion.array();
  const [probabilidadSubida, probabilidadBajada] = predicciones[0];

  if (probabilidadSubida > probabilidadBajada) {
    console.log('La predicción es que la próxima vela subirá.');
  } else {
    console.log('La predicción es que la próxima vela bajará.');
  }
};

// Ejecutar
main().catch(console.error);
