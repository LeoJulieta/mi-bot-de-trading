// sedassi_telegram_bot.js
const TelegramBot = require('node-telegram-bot-api');
const { exec } = require('child_process');

// Token de tu bot (guardalo en un archivo .env si querés más seguridad)
const token = '8027810765:AAFY-Tn0UgXNpOocaeESIv4fwFdaSu3a9ZE';

// Solo vos (Leo) podés usarlo
const ID_AUTORIZADO = 8120496449;

const bot = new TelegramBot(token, { polling: true });

bot.on('message', (msg) => {
  const chatId = msg.chat.id;
  const texto = msg.text.trim();

  // Verificación de seguridad
  if (chatId !== ID_AUTORIZADO) {
    bot.sendMessage(chatId, 'Acceso no autorizado.');
    return;
  }

  // Comandos simples
  if (texto === '/start') {
    bot.sendMessage(chatId, 'Hola Leo! SedassiBot está listo para servirte.');
  }

  if (texto === '/pipeline') {
    bot.sendMessage(chatId, 'Ejecutando pipeline...');
    exec('node pipeline.js', (error, stdout, stderr) => {
      if (error) {
        bot.sendMessage(chatId, `Error: ${error.message}`);
        return;
      }
      if (stderr) {
        bot.sendMessage(chatId, `Stderr: ${stderr}`);
        return;
      }
      bot.sendMessage(chatId, 'Pipeline completado con éxito.');
    });
  }

  if (texto === '/entrenar') {
    bot.sendMessage(chatId, 'Entrenando modelo...');
    exec('node entrenar_modelo_incremental.js', (error, stdout, stderr) => {
      if (error) {
        bot.sendMessage(chatId, `Error: ${error.message}`);
        return;
      }
      if (stderr) {
        bot.sendMessage(chatId, `Stderr: ${stderr}`);
        return;
      }
      bot.sendMessage(chatId, 'Entrenamiento completado.');
    });
  }

  if (texto === '/predecir') {
    bot.sendMessage(chatId, 'Ejecutando predicción...');
    exec('node predecir_con_modelo.js', (error, stdout, stderr) => {
      if (error) {
        bot.sendMessage(chatId, `Error: ${error.message}`);
        return;
      }
      if (stderr) {
        bot.sendMessage(chatId, `Stderr: ${stderr}`);
        return;
      }
      bot.sendMessage(chatId, 'Predicción finalizada.');
    });
  }
});
