// analizarConMartingala.js

const readline = require("readline"); const fs = require("fs"); const axios = require("axios"); const { parse } = require("csv-parse/sync");

const rl = readline.createInterface({ input: process.stdin, output: process.stdout, });

function preguntar(pregunta, valorPorDefecto) { return new Promise((resolve) => { rl.question(${pregunta} (${valorPorDefecto}): , (respuesta) => { resolve(respuesta.trim() || valorPorDefecto); }); }); }

function esDoji(vela) { return Math.abs(vela.open - vela.close) < (vela.high - vela.low) * 0.1; }

function esMartillo(vela) { const cuerpo = Math.abs(vela.open - vela.close); const mechaInferior = Math.min(vela.open, vela.close) - vela.low; const mechaSuperior = vela.high - Math.max(vela.open, vela.close); return cuerpo < mechaInferior && mechaInferior > 2 * cuerpo && mechaSuperior < cuerpo; }

function esEstrellaFugaz(vela) { const cuerpo = Math.abs(vela.open - vela.close); const mechaSuperior = vela.high - Math.max(vela.open, vela.close); const mechaInferior = Math.min(vela.open, vela.close) - vela.low; return cuerpo < mechaSuperior && mechaSuperior > 2 * cuerpo && mechaInferior < cuerpo; }

function analizarVelas(velas) { const patrones = []; for (let i = 1; i < velas.length; i++) { const vela = velas[i]; if (esDoji(vela)) { let tipo = "[Doji]"; if (esMartillo(vela)) tipo += "[Martillo]"; if (esEstrellaFugaz(vela)) tipo += "[Estrella Fugaz]"; patrones.push({ index: i, tipo }); } } return patrones; }

async function obtenerVelas(par, fecha) { const symbol = par.replace("/", ""); const interval = "1m"; const endTime = new Date(${fecha}T23:59:00Z).getTime(); const startTime = endTime - 24 * 60 * 60 * 1000;

const url = https://api.binance.com/api/v3/klines?symbol=${symbol}&interval=${interval}&startTime=${startTime}&endTime=${endTime}&limit=1440; const response = await axios.get(url); return response.data.map((v) => ({ time: new Date(v[0]), open: parseFloat(v[1]), high: parseFloat(v[2]), low: parseFloat(v[3]), close: parseFloat(v[4]), })); }

async function main() { const fecha = await preguntar("Fecha a analizar (YYYY-MM-DD)", "2025-04-16"); const par = await preguntar("Par a analizar (ej: USDT/BRL)", "USDT/BRL"); const saldoInicial = parseFloat(await preguntar("Saldo inicial", "300")); const montoBase = parseFloat(await preguntar("Monto por operación", "2")); const martingalaFactor = parseFloat(await preguntar("Factor Martingala", "2")); rl.close();

console.log("\nDescargando velas..."); const velas = await obtenerVelas(par, fecha); console.log("Velas descargadas:", velas.length);

console.log("Buscando patrones..."); const patrones = analizarVelas(velas);

const entradas = []; // Aquí se aplicarían tus reglas para decidir entradas reales

console.log("Entradas encontradas:", entradas.length); console.log("\n\nPatrones adicionales encontrados:", patrones.length); patrones.forEach((p) => { console.log(Vela ${p.index} - ${velas[p.index].time.toLocaleString()} ${p.tipo}); });

let saldo = saldoInicial; let operaciones = 0;

for (let entrada of entradas) { let monto = montoBase; let exito = false; while (!exito && saldo >= monto) { saldo -= monto; operaciones++; // Aquí deberías evaluar si la operación tuvo éxito basado en tu lógica específica const ganancia = monto * 0.9; saldo += ganancia; exito = true; } }

console.log("\nAnálisis finalizado."); console.log("Operaciones:", operaciones); console.log("Saldo final:", saldo.toFixed(2), "USDT"); }

main();

