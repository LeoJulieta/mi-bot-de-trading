const tf = require('@tensorflow/tfjs');
const fs = require('fs');

(async () => {
  try {
    console.log('[SEDASSI] Cargando modelo...');

    // Leer archivos del modelo
    const modelJSON = JSON.parse(fs.readFileSync('./modelo_entrenado/model.json', 'utf8'));
    const weightsBuffer = fs.readFileSync('./modelo_entrenado/weights.bin');

    // Nuevo formato recomendado
    const model = await tf.loadLayersModel(tf.io.fromMemory({
      modelTopology: modelJSON.modelTopology,
      weightsManifest: modelJSON.weightsManifest,
      weightData: weightsBuffer
    }));

    console.log('[SEDASSI] Modelo cargado correctamente.');

    // Cargar datos para predecir
    const datos = JSON.parse(fs.readFileSync('./resultados_convertidos.json', 'utf8'));

    // Extraer entradas y validar forma
    const entradas = datos.map(d => d.entrada);
    if (!Array.isArray(entradas) || entradas.length === 0 || !Array.isArray(entradas[0])) {
      throw new Error('Formato de entradas inválido. Esperado: array de arrays numéricos.');
    }

    const numFeatures = entradas[0].length;
    const inputs = tf.tensor2d(entradas, [entradas.length, numFeatures]);

    // Hacer predicciones
    const predicciones = model.predict(inputs);
    const resultados = await predicciones.array();

    // Guardar resultados
    const salida = datos.map((d, i) => ({
      ...d,
      prediccion: resultados[i]
    }));

    fs.writeFileSync('./predicciones.json', JSON.stringify(salida, null, 2));
    console.log('[SEDASSI] Predicciones guardadas en predicciones.json');
  } catch (error) {
    console.error('[SEDASSI] Error al cargar o predecir:', error);
  }
})();
