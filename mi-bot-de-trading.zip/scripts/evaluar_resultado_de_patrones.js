const fs = require('fs');

const patrones = JSON.parse(fs.readFileSync('resultados_patrones.json', 'utf8'));
const velas1m = JSON.parse(fs.readFileSync('./data/USDTBRL_1m.json', 'utf8'));

function obtenerVelaPosterior(timestamp) {
  return velas1m.find(v => v.timestamp > timestamp);
}

function evaluarPatron(patron) {
  if (!patron || !patron.vela || !patron.vela.timestamp) {
    console.warn('Patrón sin datos de vela:', patron);
    return { ...patron, resultado: 'sin datos de vela' };
  }

  const { tipo, vela } = patron;
  const velaPosterior = obtenerVelaPosterior(vela.timestamp);

  if (!velaPosterior) return { ...patron, resultado: 'sin vela posterior' };

  const direccionEsperada =
    tipo.includes('Bullish') || tipo.includes('Hammer') || tipo.includes('Morning') ||
    tipo.includes('Piercing') || tipo.includes('Tweezer Bottom') || tipo.includes('Breakout')
      ? 'alza'
      : tipo.includes('Bearish') || tipo.includes('Hanging') || tipo.includes('Evening') ||
        tipo.includes('Dark') || tipo.includes('Tweezer Top')
        ? 'baja'
        : null;

  if (!direccionEsperada) return { ...patron, resultado: 'indefinido' };

  const movimiento = velaPosterior.close - velaPosterior.open;
  const resultado =
    (direccionEsperada === 'alza' && movimiento > 0) ||
    (direccionEsperada === 'baja' && movimiento < 0)
      ? 'ganador'
      : 'perdedor';

  return { ...patron, resultado };
}

const resultadosEvaluados = patrones.map(evaluarPatron);

fs.writeFileSync('resultados_evaluados.json', JSON.stringify(resultadosEvaluados, null, 2));
console.log('Evaluación completada. Resultados guardados en resultados_evaluados.json');
