const fs = require('fs');

console.log('[SEDASSI] Leyendo resultados convertidos...');

const pathEntrada = 'resultados_convertidos.json';
const pathSalida = 'resultados_convertidos_limpio.json';

if (!fs.existsSync(pathEntrada)) {
  console.error(`[ERROR] No se encontró el archivo ${pathEntrada}`);
  process.exit(1);
}

const datos = JSON.parse(fs.readFileSync(pathEntrada));
const datosLimpios = [];

datos.forEach((ejemplo, i) => {
  const entradaValida = Array.isArray(ejemplo.input) &&
                        ejemplo.input.length > 0 &&
                        ejemplo.input.every(n => typeof n === 'number');

  const salidaValida = Array.isArray(ejemplo.output) &&
                       ejemplo.output.length === 1 &&
                       typeof ejemplo.output[0] === 'number';

  if (entradaValida && salidaValida) {
    datosLimpios.push(ejemplo);
  } else {
    console.warn(`[AVISO] Resultado inválido en índice ${i}, será descartado.`);
  }
});

console.log(`[SEDASSI] Resultados válidos después de limpieza: ${datosLimpios.length}`);

fs.writeFileSync(pathSalida, JSON.stringify(datosLimpios, null, 2));
console.log(`[SEDASSI] Resultados limpios guardados en ${pathSalida}`);
