// asociar_datos_vela.js
const fs = require('fs');

// Cargar los patrones detectados
const patrones = JSON.parse(fs.readFileSync('patrones_detectados.json', 'utf8'));

// Cargar las velas históricas
const datos = JSON.parse(fs.readFileSync('datos/datos.json', 'utf8'));

// Asociar la vela correspondiente al índice de cada patrón
const patronesConVela = patrones.map(p => {
  const vela = datos[p.indice + 1]; // Tomamos la vela siguiente para evaluar resultado
  if (vela) {
    return {
      ...p,
      vela_resultado: vela
    };
  } else {
    console.warn('No se encontró vela para patrón en índice:', p.indice);
    return {
      ...p,
      vela_resultado: null
    };
  }
});

// Guardar el nuevo archivo
fs.writeFileSync('patrones_con_datos_de_vela.json', JSON.stringify(patronesConVela, null, 2));
console.log('Archivo guardado: patrones_con_datos_de_vela.json');
