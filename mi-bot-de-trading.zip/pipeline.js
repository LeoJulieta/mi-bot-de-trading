const { execSync } = require('child_process');

function ejecutarScript(ruta, descripcion) {
  console.log(`\n[SEDASSI] Ejecutando: ${descripcion}`);
  try {
    execSync(`node ${ruta}`, { stdio: 'inherit' });
  } catch (error) {
    console.error(`[ERROR] Falló ${descripcion}:`, error.message);
  }
}

console.log('[SEDASSI] INICIANDO PIPELINE COMPLETO...');

// 1. Detectar patrones
ejecutarScript('detectar_patrones.cjs', 'Detección de patrones');

// 2. Asociar datos de vela siguiente
ejecutarScript('scripts/asociar_datos_vela.js', 'Asociación de vela siguiente');

// 3. Evaluar si los patrones fueron ganadores
ejecutarScript('scripts/evaluar_resultado_de_patrones.js', 'Evaluación de patrones');

// 4. Limpiar resultados evaluados antes de convertirlos
ejecutarScript('scripts/limpiar_resultados.js', 'Limpieza de resultados evaluados');

// 5. Convertir a datos para entrenamiento
ejecutarScript('convertir_a_datos_entrenamiento.js', 'Conversión para entrenamiento');

// 6. Limpiar dataset final antes de entrenar
ejecutarScript('scripts/limpiar_dataset.js', 'Limpieza de dataset');

// 7. Entrenar modelo incremental
ejecutarScript('entrenar_modelo_incremental.js', 'Entrenamiento incremental del modelo');

// 8. Realizar predicciones
ejecutarScript('predecir_con_modelo.js', 'Predicciones con el modelo');

console.log('\n[SEDASSI] PIPELINE COMPLETO FINALIZADO.');
