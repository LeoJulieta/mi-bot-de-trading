// server.js
const tf = require('@tensorflow/tfjs');
const express = require('express');
const path = require('path');

const app = express();
const modeloPath = path.join(__dirname, 'models/modelo_entrenado');

app.use('/', express.static(modeloPath));

const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Servidor TensorFlow.js corriendo en http://localhost:${PORT}`);
});
