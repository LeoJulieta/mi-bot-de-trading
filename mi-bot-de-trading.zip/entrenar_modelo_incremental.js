const tf = require('@tensorflow/tfjs');
const fs = require('fs');

// Leer y preparar datos de entrenamiento
console.log('[SEDASSI] Cargando datos de entrenamiento...');
const datosRaw = fs.readFileSync('resultados_convertidos.json', 'utf-8');
const datos = JSON.parse(datosRaw).filter(item =>
  item.vela &&
  typeof item.resultado === 'number' &&
  typeof item.vela.open === 'number' &&
  typeof item.vela.close === 'number' &&
  typeof item.vela.high === 'number' &&
  typeof item.vela.low === 'number' &&
  typeof item.vela.volume === 'number'
);

if (datos.length === 0) {
  console.log('[SEDASSI] No se encontraron datos válidos para entrenamiento.');
  process.exit(1);
}

console.log(`[SEDASSI] Entrenando modelo con ${datos.length} ejemplos...`);

// Convertir a tensores
const X = tf.tensor2d(
  datos.map(item => [
    item.vela.open,
    item.vela.close,
    item.vela.high,
    item.vela.low,
    item.vela.volume
  ])
);
const y = tf.tensor2d(
  datos.map(item => [item.resultado])
);

// Definir el modelo
const modelo = tf.sequential();
modelo.add(tf.layers.dense({ inputShape: [5], units: 16, activation: 'relu' }));
modelo.add(tf.layers.dense({ units: 8, activation: 'relu' }));
modelo.add(tf.layers.dense({ units: 1, activation: 'sigmoid' }));

modelo.compile({
  optimizer: tf.train.adam(),
  loss: 'binaryCrossentropy',
  metrics: ['accuracy']
});

// Entrenar
(async () => {
  await modelo.fit(X, y, {
    epochs: 20,
    callbacks: {
      onEpochEnd: (epoch, logs) => {
        console.log(`[Época ${epoch + 1}] pérdida: ${logs.loss.toFixed(4)} - accuracy: ${logs.acc.toFixed(4)}`);
      }
    }
  });

  console.log('[SEDASSI] Guardando modelo entrenado...');
  const data = await modelo.save(tf.io.withSaveHandler(async (modelArtifacts) => {
    const fs = require('fs');
    fs.mkdirSync('modelo_entrenado', { recursive: true });
    fs.writeFileSync('modelo_entrenado/model.json', JSON.stringify(modelArtifacts.modelTopology, null, 2));
    fs.writeFileSync('modelo_entrenado/weights.bin', Buffer.from(modelArtifacts.weightData));
    console.log('[SEDASSI] Entrenamiento completado y modelo guardado.');
    return {
      modelArtifactsInfo: {
        dateSaved: new Date(),
        modelTopologyType: 'JSON',
        weightDataBytes: modelArtifacts.weightData.byteLength
      }
    };
  }));
})();
