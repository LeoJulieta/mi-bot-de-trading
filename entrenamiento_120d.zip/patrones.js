module.exports = {
  detectarMartillo: (vela) => {
    const cuerpo = Math.abs(vela.close - vela.open);
    const sombraInferior = vela.open < vela.close
      ? vela.open - vela.low
      : vela.close - vela.low;
    const sombraSuperior = vela.high - Math.max(vela.close, vela.open);

    return (
      cuerpo > 0 &&
      sombraInferior > cuerpo * 2 &&
      sombraSuperior < cuerpo
    );
  },

  detectarDoji: (vela) => {
    const cuerpo = Math.abs(vela.close - vela.open);
    const rangoTotal = vela.high - vela.low;
    return cuerpo <= rangoTotal * 0.1;
  },

  detectarEngulfingAlcista: (velaAnterior, velaActual) => {
    return (
      velaAnterior.close < velaAnterior.open &&
      velaActual.close > velaActual.open &&
      velaActual.open < velaAnterior.close &&
      velaActual.close > velaAnterior.open
    );
  },

  detectarEngulfingBajista: (velaAnterior, velaActual) => {
    return (
      velaAnterior.close > velaAnterior.open &&
      velaActual.close < velaActual.open &&
      velaActual.open > velaAnterior.close &&
      velaActual.close < velaAnterior.open
    );
  }
};
