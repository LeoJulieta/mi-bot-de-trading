
const fs = require('fs');

const velas = JSON.parse(fs.readFileSync('./datos/velas.json'));
const memoria = {};

function detectarPatrones(velas) {
  const patrones = {};

  for (let i = 4; i < velas.length; i++) {
    const v1 = velas[i - 4];
    const v2 = velas[i - 3];
    const v3 = velas[i - 2];
    const v4 = velas[i - 1];
    const actual = velas[i];

    const esRoja = (v) => v.open > v.close;
    const esVerde = (v) => v.close > v.open;

    // Detectar el patrón: tendencia bajista con 4 cortes de velas verdes
    if (esRoja(v1) && esRoja(v2) && esRoja(v3) && esRoja(v4)) {
      if (esVerde(actual)) {
        const key = '4_rojas_y_una_verde';

        if (!patrones[key]) patrones[key] = { apariciones: 0 };
        patrones[key].apariciones += 1;
      }
    }
  }

  return patrones;
}

const patrones = detectarPatrones(velas);
console.log('Entrenamiento completado. Resultados por patrón:');
console.table(patrones);

fs.writeFileSync('memoria.json', JSON.stringify(patrones, null, 2));
console.log('Memoria actualizada en memoria.json');
