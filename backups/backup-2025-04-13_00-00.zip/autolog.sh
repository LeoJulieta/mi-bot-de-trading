#!/data/data/com.termux/files/usr/bin/bash

# Ruta base del proyecto
cd ~/mi-bot-de-trading

# Ejecutar escaneo de archivos y loguear
node tools/ls-scan.js >> logs/autolog.log 2>&1
echo "Escaneo ejecutado en: $(date)" >> logs/autolog.log

# Guardar fragmento de charla desde notificaciones (solo texto)
echo "Log de charla: $(date)" >> chatlog.md
termux-notification-list | jq -r '.[] | select(.app=="com.termux") | .summary' >> chatlog.md
echo "" >> chatlog.md

# Crear resumen diario
FECHA=$(date '+%Y-%m-%d')
RESUMEN="resumenes/$FECHA-resumen.md"
mkdir -p resumenes
echo "## Resumen del $FECHA" > "$RESUMEN"
echo "- Escaneo automático ejecutado" >> "$RESUMEN"
echo "- Backup de charla y archivos sincronizado" >> "$RESUMEN"
echo "- Cambios subidos a GitHub" >> "$RESUMEN"

# Actualizar README dinámico
echo "# Proyecto: Mi bot de trading" > README.md
echo "" >> README.md
echo "Última actualización: $(date)" >> README.md
echo "" >> README.md
echo "## Estructura de carpetas" >> README.md
tree -L 2 >> README.md
echo "" >> README.md
echo "## Últimos cambios" >> README.md
git log -3 --pretty=format:"- %h %s (%ci)" >> README.md

# Git add, commit y push
git add .
git commit -m "Auto backup y sincronización: $(date '+%Y-%m-%d %H:%M:%S')"
git push origin main >> logs/git.log 2>&1
