// Módulo de Machine Learning inicial
console.log('ML observando');