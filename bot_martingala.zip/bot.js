
// bot.js - Versión mejorada con autoajuste y registro
const fs = require('fs');
const { analizarEstrategia } = require('./registroOperaciones');
const velas = JSON.parse(fs.readFileSync('./datos/velas.json'));
let capital = 5, entradas = 0, ganadas = 0;

for (let i = 50; i < velas.length - 1; i++) {
    const resultado = analizarEstrategia(velas, i, capital);
    if (resultado) {
        capital = resultado.nuevoCapital;
        entradas++;
        if (resultado.ganada) ganadas++;
    }
}
fs.writeFileSync('./resultados/resumen-backtest.json', JSON.stringify({ entradas, ganadas, capitalFinal: capital }, null, 2));
console.log("Resumen guardado en: resultados/resumen-backtest.json");
