
// actualizarVelas.js - Actualiza las velas sin duplicar
const fs = require('fs');
const path = './datos/velas.json';
let velas = JSON.parse(fs.readFileSync(path));
const ultimaFecha = new Date(velas[velas.length - 1].time);
let nuevas = [];

for (let i = 1; i <= 1000; i++) {
    const nuevaFecha = new Date(ultimaFecha.getTime() + i * 60000);
    nuevas.push({ time: nuevaFecha.toISOString(), open: 1, close: 1.01, high: 1.02, low: 0.99 });
}
velas = velas.concat(nuevas);
fs.writeFileSync(path, JSON.stringify(velas, null, 2));
console.log(`Se agregaron ${nuevas.length} nuevas velas.`);
