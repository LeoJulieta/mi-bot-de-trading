
// registroOperaciones.js - Lógica de la estrategia y autoajuste
const fs = require('fs');
const logFile = './resultados/log-ajustes.json';
let ajustes = [];

function registrarAjuste(info) {
    ajustes.push({ fecha: new Date().toISOString(), ...info });
    fs.writeFileSync(logFile, JSON.stringify(ajustes, null, 2));
}

function analizarEstrategia(velas, i, capital) {
    const vela = velas[i];
    const decision = Math.random() > 0.5; // Simulación de decisión

    if (decision) {
        const ganada = Math.random() > 0.2;
        const nuevoCapital = capital + (ganada ? 0.5 : -1);
        registrarAjuste({ index: i, ganada, capitalAntes: capital, capitalDespues: nuevoCapital });
        return { ganada, nuevoCapital };
    }
    return null;
}

module.exports = { analizarEstrategia };
